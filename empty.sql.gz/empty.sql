
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `fx_component`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fx_component` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `keyword` varchar(255) NOT NULL,
  `name_en` varchar(255) NOT NULL,
  `description_en` text,
  `group` varchar(64) NOT NULL DEFAULT 'Main',
  `icon` varchar(255) NOT NULL,
  `store_id` text,
  `parent_id` int(11) DEFAULT NULL,
  `item_name_en` varchar(45) DEFAULT NULL,
  `name_ru` varchar(255) DEFAULT NULL,
  `item_name_ru` varchar(255) DEFAULT NULL,
  `description_ru` text,
  `vendor` varchar(255) NOT NULL,
  `declension_ru` text NOT NULL,
  `declension_en` text NOT NULL,
  `is_abstract` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `Class_Group` (`group`)
) ENGINE=InnoDB AUTO_INCREMENT=108 DEFAULT CHARSET=utf8 AVG_ROW_LENGTH=100;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `fx_component` WRITE;
/*!40000 ALTER TABLE `fx_component` DISABLE KEYS */;
INSERT INTO `fx_component` VALUES (1,'floxim.user.user','User','','','','component.user',36,'User','Пользователи','Пользователь','','','{\"nom\":{\"singular\":\"\\u043f\\u043e\\u043b\\u044c\\u0437\\u043e\\u0432\\u0430\\u0442\\u0435\\u043b\\u044c\",\"plural\":\"\\u043f\\u043e\\u043b\\u044c\\u0437\\u043e\\u0432\\u0430\\u0442\\u0435\\u043b\\u0438\"},\"gen\":{\"singular\":\"\\u043f\\u043e\\u043b\\u044c\\u0437\\u043e\\u0432\\u0430\\u0442\\u0435\\u043b\\u044f\",\"plural\":\"\\u043f\\u043e\\u043b\\u044c\\u0437\\u043e\\u0432\\u0430\\u0442\\u0435\\u043b\\u0435\\u0439\"},\"dat\":{\"singular\":\"\\u043f\\u043e\\u043b\\u044c\\u0437\\u043e\\u0432\\u0430\\u0442\\u0435\\u043b\\u044e\",\"plural\":\"\\u043f\\u043e\\u043b\\u044c\\u0437\\u043e\\u0432\\u0430\\u0442\\u0435\\u043b\\u044e\"},\"acc\":{\"singular\":\"\\u043f\\u043e\\u043b\\u044c\\u0437\\u043e\\u0432\\u0430\\u0442\\u0435\\u043b\\u044f\",\"plural\":\"\\u043f\\u043e\\u043b\\u044c\\u0437\\u043e\\u0432\\u0430\\u0442\\u0435\\u043b\\u0435\\u0439\"},\"inst\":{\"singular\":\"\\u043f\\u043e\\u043b\\u044c\\u0437\\u043e\\u0432\\u0430\\u0442\\u0435\\u043b\\u0435\\u043c\",\"plural\":\"\\u043f\\u043e\\u043b\\u044c\\u0437\\u043e\\u0432\\u0430\\u0442\\u0435\\u043b\\u044f\\u043c\\u0438\"},\"prep\":{\"singular\":\"\\u043f\\u043e\\u043b\\u044c\\u0437\\u043e\\u0432\\u0430\\u0442\\u0435\\u043b\\u0435\",\"plural\":\"\\u043f\\u043e\\u043b\\u044c\\u0437\\u043e\\u0432\\u0430\\u0442\\u0435\\u043b\\u044f\\u0445\"}}','',0),(19,'floxim.main.text','Text','','','','component.text',36,'text','Текст','Текст','','','{\"nom\":{\"singular\":\"\\u0442\\u0435\\u043a\\u0441\\u0442\",\"plural\":\"\\u0442\\u0435\\u043a\\u0441\\u0442\\u044b\"},\"gen\":{\"singular\":\"\\u0442\\u0435\\u043a\\u0441\\u0442\\u0430\",\"plural\":\"\\u0442\\u0435\\u043a\\u0441\\u0442\\u043e\\u0432\"},\"dat\":{\"singular\":\"\\u0442\\u0435\\u043a\\u0441\\u0442\\u0443\",\"plural\":\"\\u0442\\u0435\\u043a\\u0441\\u0442\\u0430\\u043c\"},\"acc\":{\"singular\":\"\\u0442\\u0435\\u043a\\u0441\\u0442\",\"plural\":\"\\u0442\\u0435\\u043a\\u0441\\u0442\\u044b\"},\"inst\":{\"singular\":\"\\u0442\\u0435\\u043a\\u0441\\u0442\\u043e\\u043c\",\"plural\":\"\\u0442\\u0435\\u043a\\u0441\\u0442\\u0430\\u043c\\u0438\"},\"prep\":{\"singular\":\"\\u0442\\u0435\\u043a\\u0441\\u0442\\u0435\",\"plural\":\"\\u0442\\u0435\\u043a\\u0441\\u0442\\u0430\\u0445\"}}','',0),(23,'floxim.main.page','Page','','','',NULL,36,'page','Страницы','Страница','','','{\"nom\":{\"singular\":\"\\u0441\\u0442\\u0440\\u0430\\u043d\\u0438\\u0446\\u0430\",\"plural\":\"\\u0441\\u0442\\u0440\\u0430\\u043d\\u0438\\u0446\\u044b\"},\"gen\":{\"singular\":\"\\u0441\\u0442\\u0440\\u0430\\u043d\\u0438\\u0446\\u044b\",\"plural\":\"\\u0441\\u0442\\u0440\\u0430\\u043d\\u0438\\u0446\"},\"dat\":{\"singular\":\"\\u0441\\u0442\\u0440\\u0430\\u043d\\u0438\\u0446\\u0435\",\"plural\":\"\\u0441\\u0442\\u0440\\u0430\\u043d\\u0438\\u0446\\u0430\\u043c\"},\"acc\":{\"singular\":\"\\u0441\\u0442\\u0440\\u0430\\u043d\\u0438\\u0446\\u0443\",\"plural\":\"\\u0441\\u0442\\u0440\\u0430\\u043d\\u0438\\u0446\\u044b\"},\"inst\":{\"singular\":\"\\u0441\\u0442\\u0440\\u0430\\u043d\\u0438\\u0446\\u0435\\u0439\",\"plural\":\"\\u0441\\u0442\\u0440\\u0430\\u043d\\u0438\\u0446\\u0430\\u043c\\u0438\"},\"prep\":{\"singular\":\"\\u0441\\u0442\\u0440\\u0430\\u043d\\u0438\\u0446\\u0435\",\"plural\":\"\\u0441\\u0442\\u0440\\u0430\\u043d\\u0438\\u0446\\u0430\\u0445\"}}','',0),(24,'floxim.nav.section','Section','','','',NULL,23,'','Разделы','Раздел','','','{\"nom\":{\"singular\":\"\\u0440\\u0430\\u0437\\u0434\\u0435\\u043b\",\"plural\":\"\\u0440\\u0430\\u0437\\u0434\\u0435\\u043b\\u044b\"},\"gen\":{\"singular\":\"\\u0440\\u0430\\u0437\\u0434\\u0435\\u043b\\u0430\",\"plural\":\"\\u0440\\u0430\\u0437\\u0434\\u0435\\u043b\\u043e\\u0432\"},\"dat\":{\"singular\":\"\\u0440\\u0430\\u0437\\u0434\\u0435\\u043b\\u0443\",\"plural\":\"\\u0440\\u0430\\u0437\\u0434\\u0435\\u043b\\u0430\\u043c\"},\"acc\":{\"singular\":\"\\u0440\\u0430\\u0437\\u0434\\u0435\\u043b\",\"plural\":\"\\u0440\\u0430\\u0437\\u0434\\u0435\\u043b\\u044b\"},\"inst\":{\"singular\":\"\\u0440\\u0430\\u0437\\u0434\\u0435\\u043b\\u043e\\u043c\",\"plural\":\"\\u0440\\u0430\\u0437\\u0434\\u0435\\u043b\\u0430\\u043c\\u0438\"},\"prep\":{\"singular\":\"\\u0440\\u0430\\u0437\\u0434\\u0435\\u043b\\u0435\",\"plural\":\"\\u0440\\u0430\\u0437\\u0434\\u0435\\u043b\\u0430\\u0445\"}}','',0),(36,'floxim.main.content','Content','','Basic','',NULL,0,'Content','Контент','Контент',NULL,'','{\"nom\":{\"singular\":\"\\u043a\\u043e\\u043d\\u0442\\u0435\\u043d\\u0442\",\"plural\":\"\\u043a\\u043e\\u043d\\u0442\\u0435\\u043d\\u0442\\u044b\"},\"gen\":{\"singular\":\"\",\"plural\":\"\"},\"dat\":{\"singular\":\"\",\"plural\":\"\"},\"acc\":{\"singular\":\"\\u043a\\u043e\\u043d\\u0442\\u0435\\u043d\\u0442\",\"plural\":\"\"},\"inst\":{\"singular\":\"\",\"plural\":\"\"},\"prep\":{\"singular\":\"\",\"plural\":\"\"}}','',1),(48,'floxim.media.photo','Photo','','','',NULL,36,'Photo','Фото','Фото','','','{\"nom\":{\"singular\":\"\\u0444\\u043e\\u0442\\u043e\",\"plural\":\"\"},\"gen\":{\"singular\":\"\",\"plural\":\"\"},\"dat\":{\"singular\":\"\",\"plural\":\"\"},\"acc\":{\"singular\":\"\\u0444\\u043e\\u0442\\u043e\",\"plural\":\"\"},\"inst\":{\"singular\":\"\",\"plural\":\"\"},\"prep\":{\"singular\":\"\",\"plural\":\"\"}}','',0),(49,'floxim.blog.publication','Publication','','','',NULL,23,'Publication','Публикации','Публикация','','','{\"nom\":{\"singular\":\"\\u043f\\u0443\\u0431\\u043b\\u0438\\u043a\\u0430\\u0446\\u0438\\u044f\",\"plural\":\"\\u043f\\u0443\\u0431\\u043b\\u0438\\u043a\\u0430\\u0446\\u0438\\u0438\"},\"gen\":{\"singular\":\"\\u043f\\u0443\\u0431\\u043b\\u0438\\u043a\\u0430\\u0446\\u0438\\u0438\",\"plural\":\"\\u043f\\u0443\\u0431\\u043b\\u0438\\u043a\\u0430\\u0446\\u0438\\u0439\"},\"dat\":{\"singular\":\"\\u043f\\u0443\\u0431\\u043b\\u0438\\u043a\\u0430\\u0446\\u0438\\u0435\",\"plural\":\"\\u043f\\u0443\\u0431\\u043b\\u0438\\u043a\\u0430\\u0446\\u0438\\u044f\\u043c\"},\"acc\":{\"singular\":\"\\u043f\\u0443\\u0431\\u043b\\u0438\\u043a\\u0430\\u0446\\u0438\\u044e\",\"plural\":\"\\u043f\\u0443\\u0431\\u043b\\u0438\\u043a\\u0430\\u0446\\u0438\\u0438\"},\"inst\":{\"singular\":\"\\u043f\\u0443\\u0431\\u043b\\u0438\\u043a\\u0430\\u0446\\u0438\\u0435\\u0439\",\"plural\":\"\\u043f\\u0443\\u0431\\u043b\\u0438\\u043a\\u0430\\u0446\\u0438\\u044f\\u043c\\u0438\"},\"prep\":{\"singular\":\"\\u043f\\u0443\\u0431\\u043b\\u0438\\u043a\\u0430\\u0446\\u0438\\u0438\",\"plural\":\"\\u043f\\u0443\\u0431\\u043b\\u0438\\u043a\\u0430\\u0446\\u0438\\u044f\\u0445\"}}','',1),(59,'floxim.media.video','Video',NULL,'','',NULL,36,'Video','Видео','Видео','','','','',0),(62,'floxim.corporate.project','Project',NULL,'','',NULL,23,'Project','Проекты','Проект','','','{\"nom\":{\"singular\":\"\\u043f\\u0440\\u043e\\u0435\\u043a\\u0442\",\"plural\":\"\\u043f\\u0440\\u043e\\u0435\\u043a\\u0442\\u044b\"},\"gen\":{\"singular\":\"\\u043f\\u0440\\u043e\\u0435\\u043a\\u0442\\u0430\",\"plural\":\"\\u043f\\u0440\\u043e\\u0435\\u043a\\u0442\\u043e\\u0432\"},\"dat\":{\"singular\":\"\\u043f\\u0440\\u043e\\u0435\\u043a\\u0442\\u0443\",\"plural\":\"\\u043f\\u0440\\u043e\\u0435\\u043a\\u0442\\u0430\\u043c\"},\"acc\":{\"singular\":\"\\u043f\\u0440\\u043e\\u0435\\u043a\\u0442\",\"plural\":\"\\u043f\\u0440\\u043e\\u0435\\u043a\\u0442\\u044b\"},\"inst\":{\"singular\":\"\\u043f\\u0440\\u043e\\u0435\\u043a\\u0442\\u043e\\u043c\",\"plural\":\"\\u043f\\u0440\\u043e\\u0435\\u043a\\u0442\\u0430\\u043c\\u0438\"},\"prep\":{\"singular\":\"\\u043f\\u0440\\u043e\\u0435\\u043a\\u0442\\u0435\",\"plural\":\"\\u043f\\u0440\\u043e\\u0435\\u043a\\u0442\\u0430\\u0445\"}}','',0),(63,'floxim.corporate.vacancy','Vacancy',NULL,'','',NULL,23,'Vacancy','Вакансии','Вакансия','','','','',0),(64,'floxim.nav.classifier','Classifier','','','',NULL,23,'Classifier','Классификаторы','Классификатор','','','{\"nom\":{\"singular\":\"\",\"plural\":\"\"},\"gen\":{\"singular\":\"\",\"plural\":\"\"},\"dat\":{\"singular\":\"\",\"plural\":\"\"},\"acc\":{\"singular\":\"\",\"plural\":\"\"},\"inst\":{\"singular\":\"\",\"plural\":\"\"},\"prep\":{\"singular\":\"\",\"plural\":\"\"}}','',1),(68,'floxim.blog.news','News',NULL,'','',NULL,49,'News','Новости','Новость','','','{\"nom\":{\"singular\":\"\\u043d\\u043e\\u0432\\u043e\\u0441\\u0442\\u044c\",\"plural\":\"\\u043d\\u043e\\u0432\\u043e\\u0441\\u0442\\u0438\"},\"gen\":{\"singular\":\"\\u043d\\u043e\\u0432\\u043e\\u0441\\u0442\\u0438\",\"plural\":\"\\u043d\\u043e\\u0432\\u043e\\u0441\\u0442\\u0435\\u0439\"},\"dat\":{\"singular\":\"\\u043d\\u043e\\u0432\\u043e\\u0441\\u0442\\u0438\",\"plural\":\"\\u043d\\u043e\\u0432\\u043e\\u0441\\u0442\\u044f\\u043c\"},\"acc\":{\"singular\":\"\\u043d\\u043e\\u0432\\u043e\\u0441\\u0442\\u044c\",\"plural\":\"\\u043d\\u043e\\u0432\\u043e\\u0441\\u0442\\u0438\"},\"inst\":{\"singular\":\"\\u043d\\u043e\\u0432\\u043e\\u0441\\u0442\\u044c\\u044e\",\"plural\":\"\\u043d\\u043e\\u0432\\u043e\\u0441\\u0442\\u044f\\u043c\\u0438\"},\"prep\":{\"singular\":\"\\u043d\\u043e\\u0432\\u043e\\u0441\\u0442\\u0438\",\"plural\":\"\\u043d\\u043e\\u0432\\u043e\\u0441\\u0442\\u044f\\u0445\"}}','',0),(69,'floxim.corporate.person','Person',NULL,'','',NULL,23,'Person','Персоналии','Персона','','','','',0),(70,'floxim.corporate.contact','Contact',NULL,'','',NULL,36,'Contact','Контакты','Контакт','','','','',0),(75,'floxim.shop.product','Product',NULL,'','',NULL,23,'Product','Продукты','Продукт','','','','',0),(77,'floxim.main.linker','Linker',NULL,'','',NULL,36,'Linker','Привязка','Привязка','','','{\"nom\":{\"singular\":\"\\u043f\\u0440\\u0438\\u0432\\u044f\\u0437\\u043a\\u0430\",\"plural\":\"\\u043f\\u0440\\u0438\\u0432\\u044f\\u0437\\u043a\\u0438\"},\"gen\":{\"singular\":\"\",\"plural\":\"\"},\"dat\":{\"singular\":\"\",\"plural\":\"\"},\"acc\":{\"singular\":\"\\u043f\\u0440\\u0438\\u0432\\u044f\\u0437\\u043a\\u0443\",\"plural\":\"\"},\"inst\":{\"singular\":\"\",\"plural\":\"\"},\"prep\":{\"singular\":\"\",\"plural\":\"\"}}','',0),(78,'floxim.nav.tag','Tag','','','',NULL,64,'Tag','Теги','Тег','','','{\"nom\":{\"singular\":\"\\u0442\\u0435\\u0433\",\"plural\":\"\\u0442\\u0435\\u0433\\u0438\"},\"gen\":{\"singular\":\"\\u0442\\u0435\\u0433\\u0430\",\"plural\":\"\\u0442\\u0435\\u0433\\u043e\\u0432\"},\"dat\":{\"singular\":\"\\u0442\\u0435\\u0433\\u0443\",\"plural\":\"\\u0442\\u0435\\u0433\\u0430\\u043c\"},\"acc\":{\"singular\":\"\\u0442\\u0435\\u0433\",\"plural\":\"\\u0442\\u0435\\u0433\\u0438\"},\"inst\":{\"singular\":\"\\u0442\\u0435\\u0433\\u043e\\u043c\",\"plural\":\"\\u0442\\u0435\\u0433\\u0430\\u043c\\u0438\"},\"prep\":{\"singular\":\"\\u0442\\u0435\\u0433\\u0435\",\"plural\":\"\\u0442\\u0435\\u0433\\u0430\\u0445\"}}','',0),(80,'floxim.main.message_template','Message template',NULL,'Main','',NULL,36,'Message template','Шаблоны сообщений','Шаблон сообщения','','','','',0),(81,'floxim.main.mail_template','Mail template',NULL,'Main','',NULL,80,'Mail template','Почтовые шаблоны','Почтовый шаблон','','','','',0),(84,'floxim_saas.content.pic_text','',NULL,'Main','',NULL,19,NULL,'Текст с картинкой',NULL,NULL,'','{\"nom\":{\"singular\":\"\\u0442\\u0435\\u043a\\u0441\\u0442 \\u0441 \\u043a\\u0430\\u0440\\u0442\\u0438\\u043d\\u043a\\u043e\\u0439\",\"plural\":\"\\u0442\\u0435\\u043a\\u0441\\u0442\\u044b\"},\"gen\":{\"singular\":\"\\u0442\\u0435\\u043a\\u0441\\u0442\\u0430 \\u0441 \\u043a\\u0430\\u0440\\u0442\\u0438\\u043d\\u043a\\u0430\\u043c\\u0438\",\"plural\":\"\"},\"dat\":{\"singular\":\"\",\"plural\":\"\"},\"acc\":{\"singular\":\"\\u0442\\u0435\\u043a\\u0441\\u0442 \\u0441 \\u043a\\u0430\\u0440\\u0442\\u0438\\u043d\\u043a\\u043e\\u0439\",\"plural\":\"\"},\"inst\":{\"singular\":\"\",\"plural\":\"\\u0442\\u0435\\u043a\\u0441\\u0442\\u0430\\u043c\\u0438\"},\"prep\":{\"singular\":\"\",\"plural\":\"\"}}','',0),(85,'floxim_saas.content.logo','',NULL,'Main','',NULL,36,NULL,'Логотип',NULL,NULL,'','{\"nom\":{\"singular\":\"\\u043b\\u043e\\u0433\\u043e\\u0442\\u0438\\u043f\",\"plural\":\"\\u043b\\u043e\\u0433\\u043e\\u0442\\u0438\\u043f\\u044b\"},\"gen\":{\"singular\":\"\\u043b\\u043e\\u0433\\u043e\\u0442\\u0438\\u043f\\u0430\",\"plural\":\"\\u043b\\u043e\\u0433\\u043e\\u0442\\u0438\\u043f\\u043e\\u0432\"},\"dat\":{\"singular\":\"\\u043b\\u043e\\u0433\\u043e\\u0442\\u0438\\u043f\\u0443\",\"plural\":\"\\u043b\\u043e\\u0433\\u043e\\u0442\\u0438\\u043f\\u0430\\u043c\"},\"acc\":{\"singular\":\"\\u043b\\u043e\\u0433\\u043e\\u0442\\u0438\\u043f\",\"plural\":\"\\u043b\\u043e\\u0433\\u043e\\u0442\\u0438\\u043f\\u044b\"},\"inst\":{\"singular\":\"\\u043b\\u043e\\u0433\\u043e\\u0442\\u0438\\u043f\\u043e\\u043c\",\"plural\":\"\\u043b\\u043e\\u0433\\u043e\\u0442\\u0438\\u043f\\u0430\\u043c\\u0438\"},\"prep\":{\"singular\":\"\\u043b\\u043e\\u0433\\u043e\\u0442\\u0438\\u043f\\u0435\",\"plural\":\"\\u043b\\u043e\\u0433\\u043e\\u0442\\u0438\\u043f\\u0430\\u0445\"}}','',0),(87,'floxim_saas.contacts.contact','',NULL,'Main','',NULL,36,NULL,'Контакты',NULL,NULL,'','{\"nom\":{\"singular\":\"\\u043a\\u043e\\u043d\\u0442\\u0430\\u043a\\u0442\",\"plural\":\"\\u043a\\u043e\\u043d\\u0442\\u0430\\u043a\\u0442\\u044b\"},\"gen\":{\"singular\":\"\\u043a\\u043e\\u043d\\u0442\\u0430\\u043a\\u0442\\u0430\",\"plural\":\"\\u043a\\u043e\\u043d\\u0442\\u0430\\u043a\\u0442\\u043e\\u0432\"},\"dat\":{\"singular\":\"\\u043a\\u043e\\u043d\\u0442\\u0430\\u043a\\u0442\\u0443\",\"plural\":\"\\u043a\\u043e\\u043d\\u0442\\u0430\\u043a\\u0442\\u0430\\u043c\"},\"acc\":{\"singular\":\"\\u043a\\u043e\\u043d\\u0442\\u0430\\u043a\\u0442\",\"plural\":\"\\u043a\\u043e\\u043d\\u0442\\u0430\\u043a\\u0442\\u044b\"},\"inst\":{\"singular\":\"\\u043a\\u043e\\u043d\\u0442\\u0430\\u043a\\u0442\\u043e\\u043c\",\"plural\":\"\\u043a\\u043e\\u043d\\u0442\\u0430\\u043a\\u0442\\u0430\\u043c\\u0438\"},\"prep\":{\"singular\":\"\\u043a\\u043e\\u043d\\u0442\\u0430\\u043a\\u0442\\u0435\",\"plural\":\"\\u043a\\u043e\\u043d\\u0442\\u0430\\u043a\\u0442\\u0430\\u0445\"}}','',1),(88,'floxim_saas.contacts.phone','',NULL,'Main','',NULL,87,NULL,'Телефон',NULL,NULL,'','{\"nom\":{\"singular\":\"\\u0442\\u0435\\u043b\\u0435\\u0444\\u043e\\u043d\",\"plural\":\"\\u0442\\u0435\\u043b\\u0435\\u0444\\u043e\\u043d\\u044b\"},\"gen\":{\"singular\":\"\",\"plural\":\"\"},\"dat\":{\"singular\":\"\",\"plural\":\"\"},\"acc\":{\"singular\":\"\\u0442\\u0435\\u043b\\u0435\\u0444\\u043e\\u043d\",\"plural\":\"\"},\"inst\":{\"singular\":\"\",\"plural\":\"\"},\"prep\":{\"singular\":\"\",\"plural\":\"\"}}','',0),(89,'floxim_saas.contacts.email','',NULL,'Main','',NULL,87,NULL,'E-mail',NULL,NULL,'','{\"nom\":{\"singular\":\"e-mail\",\"plural\":\"\"},\"gen\":{\"singular\":\"\",\"plural\":\"\"},\"dat\":{\"singular\":\"\",\"plural\":\"\"},\"acc\":{\"singular\":\"e-mail\",\"plural\":\"\"},\"inst\":{\"singular\":\"\",\"plural\":\"\"},\"prep\":{\"singular\":\"\",\"plural\":\"\"}}','',0),(90,'floxim_saas.contacts.link','',NULL,'Main','',NULL,87,NULL,'Ссылка',NULL,NULL,'','{\"nom\":{\"singular\":\"\\u0441\\u0441\\u044b\\u043b\\u043a\\u0430\",\"plural\":\"\\u0441\\u0441\\u044b\\u043b\\u043a\\u0438\"},\"gen\":{\"singular\":\"\",\"plural\":\"\"},\"dat\":{\"singular\":\"\",\"plural\":\"\"},\"acc\":{\"singular\":\"\\u0441\\u0441\\u044b\\u043b\\u043a\\u0443\",\"plural\":\"\"},\"inst\":{\"singular\":\"\",\"plural\":\"\"},\"prep\":{\"singular\":\"\",\"plural\":\"\"}}','',0),(91,'floxim_saas.contacts.address','',NULL,'Main','',NULL,87,NULL,'Адрес',NULL,NULL,'','{\"nom\":{\"singular\":\"\\u0430\\u0434\\u0440\\u0435\\u0441\",\"plural\":\"\\u0430\\u0434\\u0440\\u0435\\u0441\\u0430\"},\"gen\":{\"singular\":\"\\u0430\\u0434\\u0440\\u0435\\u0441\\u0430\",\"plural\":\"\\u0430\\u0434\\u0440\\u0435\\u0441\\u043e\\u0432\"},\"dat\":{\"singular\":\"\\u0430\\u0434\\u0440\\u0435\\u0441\\u0443\",\"plural\":\"\\u0430\\u0434\\u0440\\u0435\\u0441\\u0430\\u043c\"},\"acc\":{\"singular\":\"\\u0430\\u0434\\u0440\\u0435\\u0441\",\"plural\":\"\\u0430\\u0434\\u0440\\u0435\\u0441\\u0430\"},\"inst\":{\"singular\":\"\\u0430\\u0434\\u0440\\u0435\\u0441\\u043e\\u043c\",\"plural\":\"\\u0430\\u0434\\u0440\\u0435\\u0441\\u0430\\u043c\\u0438\"},\"prep\":{\"singular\":\"\\u0430\\u0434\\u0440\\u0435\\u0441\\u0435\",\"plural\":\"\\u0430\\u0434\\u0440\\u0435\\u0441\\u0430\\u0445\"}}','',0),(92,'floxim_saas.content.service','',NULL,'Main','',NULL,75,NULL,'Услуги',NULL,NULL,'','{\"nom\":{\"singular\":\"\\u0443\\u0441\\u043b\\u0443\\u0433\\u0430\",\"plural\":\"\\u0443\\u0441\\u043b\\u0443\\u0433\\u0438\"},\"gen\":{\"singular\":\"\\u0443\\u0441\\u043b\\u0443\\u0433\\u0438\",\"plural\":\"\\u0443\\u0441\\u043b\\u0443\\u0433\"},\"dat\":{\"singular\":\"\\u0443\\u0441\\u043b\\u0443\\u0433\\u0435\",\"plural\":\"\\u0443\\u0441\\u043b\\u0443\\u0433\\u0430\\u043c\"},\"acc\":{\"singular\":\"\\u0443\\u0441\\u043b\\u0443\\u0433\\u0443\",\"plural\":\"\\u0443\\u0441\\u043b\\u0443\\u0433\\u0438\"},\"inst\":{\"singular\":\"\\u0443\\u0441\\u043b\\u0443\\u0433\\u043e\\u0439\",\"plural\":\"\\u0443\\u0441\\u043b\\u0443\\u0433\\u0430\\u043c\\u0438\"},\"prep\":{\"singular\":\"\\u0443\\u0441\\u043b\\u0443\\u0433\\u0435\",\"plural\":\"\\u0443\\u0441\\u043b\\u0443\\u0433\\u0430\\u0445\"}}','',0),(103,'floxim_saas.saas.user','',NULL,'Main','',NULL,1,NULL,'Пользователь',NULL,NULL,'','','',0),(106,'floxim_saas.content.reviews','',NULL,'Main','',NULL,23,NULL,'Отзывы',NULL,NULL,'','{\"nom\":{\"singular\":\"\\u043e\\u0442\\u0437\\u044b\\u0432\",\"plural\":\"\\u043e\\u0442\\u0437\\u044b\\u0432\\u044b\"},\"gen\":{\"singular\":\"\\u043e\\u0442\\u0437\\u044b\\u0432\\u0430\",\"plural\":\"\\u043e\\u0442\\u0437\\u044b\\u0432\\u043e\\u0432\"},\"dat\":{\"singular\":\"\\u043e\\u0442\\u0437\\u044b\\u0432\\u0443\",\"plural\":\"\\u043e\\u0442\\u0437\\u044b\\u0432\\u0430\\u043c\"},\"acc\":{\"singular\":\"\\u043e\\u0442\\u0437\\u044b\\u0432\",\"plural\":\"\\u043e\\u0442\\u0437\\u044b\\u0432\\u044b\"},\"inst\":{\"singular\":\"\\u043e\\u0442\\u0437\\u044b\\u0432\\u043e\\u043c\",\"plural\":\"\\u043e\\u0442\\u0437\\u044b\\u0432\\u0430\\u043c\\u0438\"},\"prep\":{\"singular\":\"\\u043e\\u0442\\u0437\\u044b\\u0432\\u0435\",\"plural\":\"\\u043e\\u0442\\u0437\\u044b\\u0432\\u0430\\u0445\"}}','',0),(107,'floxim.layout.column','',NULL,'Main','',NULL,36,NULL,'Колонки',NULL,NULL,'','{\"nom\":{\"singular\":\"\\u043a\\u043e\\u043b\\u043e\\u043d\\u043a\\u0430\",\"plural\":\"\\u043a\\u043e\\u043b\\u043e\\u043d\\u043a\\u0438\"},\"gen\":{\"singular\":\"\\u043a\\u043e\\u043b\\u043e\\u043d\\u043a\\u0438\",\"plural\":\"\\u043a\\u043e\\u043b\\u043e\\u043d\\u043e\\u043a\"},\"dat\":{\"singular\":\"\\u043a\\u043e\\u043b\\u043e\\u043d\\u043a\\u0435\",\"plural\":\"\\u043a\\u043e\\u043b\\u043e\\u043d\\u043a\\u0430\\u043c\"},\"acc\":{\"singular\":\"\\u043a\\u043e\\u043b\\u043e\\u043d\\u043a\\u0443\",\"plural\":\"\\u043a\\u043e\\u043b\\u043e\\u043d\\u043a\\u0438\"},\"inst\":{\"singular\":\"\\u043a\\u043e\\u043b\\u043e\\u043d\\u043a\\u043e\\u0439\",\"plural\":\"\\u043a\\u043e\\u043b\\u043e\\u043d\\u043a\\u0430\\u043c\\u0438\"},\"prep\":{\"singular\":\"\\u043a\\u043e\\u043b\\u043e\\u043d\\u043a\\u0435\",\"plural\":\"\\u043a\\u043e\\u043b\\u043e\\u043d\\u043a\\u0430\\u0445\"}}','',0);
/*!40000 ALTER TABLE `fx_component` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `fx_datatype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fx_datatype` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `keyword` char(64) NOT NULL,
  `priority` int(11) DEFAULT NULL,
  `name_en` varchar(255) NOT NULL,
  `name_ru` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 AVG_ROW_LENGTH=204;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `fx_datatype` WRITE;
/*!40000 ALTER TABLE `fx_datatype` DISABLE KEYS */;
INSERT INTO `fx_datatype` VALUES (1,'string',1,'String','Строка'),(2,'int',3,'Number','Число'),(3,'text',2,'Text','Текст'),(4,'select',14,'List of values','Выбор из списка'),(5,'bool',6,'Checkbox','Чекбокс'),(6,'file',10,'File','Файл'),(7,'float',13,'Float number','Дробное число'),(8,'datetime',8,'Date and time','Дата и время'),(9,'color',9,'Color','Цвет'),(11,'image',4,'Image','Изображение'),(13,'link',5,'Link','Ссылка на другой объект'),(14,'multilink',6,'Multiple link','Множественная связь'),(15,'group',10,'Group','Группа полей');
/*!40000 ALTER TABLE `fx_datatype` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `fx_field`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fx_field` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `component_id` int(11) DEFAULT NULL,
  `infoblock_id` int(11) DEFAULT NULL,
  `parent_field_id` int(10) unsigned DEFAULT NULL,
  `keyword` char(64) DEFAULT NULL,
  `priority` decimal(6,3) DEFAULT NULL,
  `name_en` varchar(255) DEFAULT NULL,
  `name_ru` varchar(255) DEFAULT NULL,
  `description_en` text,
  `description_ru` text,
  `type` varchar(50) DEFAULT NULL,
  `group_id` int(10) unsigned DEFAULT NULL,
  `format` text,
  `default` char(255) DEFAULT NULL,
  `is_editable` tinyint(4) DEFAULT NULL,
  `is_required` tinyint(3) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `component_id` (`component_id`),
  KEY `TypeOfEdit_ID` (`is_editable`)
) ENGINE=InnoDB AUTO_INCREMENT=474 DEFAULT CHARSET=utf8 AVG_ROW_LENGTH=95;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `fx_field` WRITE;
/*!40000 ALTER TABLE `fx_field` DISABLE KEYS */;
INSERT INTO `fx_field` VALUES (1,1,NULL,NULL,'name',0.000,'Screen name','Отображаемое имя',NULL,NULL,'string',NULL,'','',1,0),(2,1,NULL,NULL,'avatar',0.000,'Userpic','Аватар',NULL,NULL,'image',NULL,'','',1,0),(118,19,NULL,NULL,'text',7.000,'Text','Текст',NULL,NULL,'text',NULL,'{\"html\":\"1\",\"nl2br\":\"0\"}','',1,0),(153,1,NULL,NULL,'email',142.000,'E-mail','',NULL,NULL,'string',NULL,'',NULL,1,0),(165,23,NULL,NULL,'url',12.000,'URL','URL',NULL,NULL,'string',431,'{\"html\":\"0\"}','',1,0),(190,23,NULL,NULL,'name',10.000,'Name','Название',NULL,NULL,'string',NULL,'','',1,1),(191,23,NULL,NULL,'title',13.000,'Title','Title',NULL,NULL,'string',431,'{\"html\":\"0\"}','',1,0),(196,36,NULL,NULL,'parent_id',2.000,'Parent','Родитель',NULL,NULL,'link',NULL,'{\"target\":\"36\",\"prop_name\":\"parent\",\"cascade_delete\":\"0\",\"render_type\":\"livesearch\"}','',1,0),(203,48,NULL,NULL,'image',168.000,'Image','Image',NULL,NULL,'image',NULL,'','',1,0),(204,48,NULL,NULL,'description',169.000,'Description','',NULL,NULL,'text',NULL,'{\"html\":\"1\",\"nl2br\":\"0\"}','',1,0),(205,48,NULL,NULL,'copy',170.000,'Copy','',NULL,NULL,'string',NULL,'','',1,0),(212,49,NULL,NULL,'publish_date',1.000,'Publish date','Дата публикации',NULL,NULL,'datetime',NULL,'','now',1,0),(216,1,NULL,NULL,'is_admin',178.000,'Is admin?','Админ?',NULL,NULL,'bool',NULL,'','0',1,0),(230,59,NULL,NULL,'embed_html',187.000,'Embed code or link','',NULL,NULL,'text',NULL,'{\"html\":\"0\",\"nl2br\":\"0\"}','',1,0),(231,59,NULL,NULL,'description',188.000,'Description','',NULL,NULL,'text',NULL,'{\"html\":\"1\",\"nl2br\":\"0\"}','',1,0),(238,62,NULL,NULL,'image',195.000,'Image','Изображение',NULL,NULL,'image',NULL,'','',1,0),(242,62,NULL,NULL,'date',199.000,'Date','Дата',NULL,NULL,'datetime',NULL,'','',1,0),(244,63,NULL,NULL,'salary_from',201.000,'Salary from','',NULL,NULL,'int',NULL,'','',1,0),(245,63,NULL,NULL,'salary_to',202.000,'Salary To','',NULL,NULL,'int',NULL,'','',1,0),(246,63,NULL,NULL,'requirements',203.000,'Requirements','',NULL,NULL,'text',NULL,'{\"html\":\"1\",\"nl2br\":\"0\"}','',1,0),(247,63,NULL,NULL,'responsibilities',204.000,'Responsibilities','',NULL,NULL,'text',NULL,'{\"html\":\"1\",\"nl2br\":\"0\"}','',1,0),(248,63,NULL,NULL,'work_conditions',205.000,'Work conditions','',NULL,NULL,'text',NULL,'{\"html\":\"1\",\"nl2br\":\"0\"}','',1,0),(253,64,NULL,NULL,'counter',210.000,'Counter','',NULL,NULL,'int',NULL,'','0',0,0),(257,69,NULL,NULL,'full_name',214.000,'Full Name','',NULL,NULL,'string',NULL,'','',1,0),(259,69,NULL,NULL,'department',216.000,'Department','',NULL,NULL,'string',NULL,'','',1,0),(260,69,NULL,NULL,'photo',217.000,'Photo','',NULL,NULL,'image',NULL,'','',1,0),(261,69,NULL,NULL,'short_description',218.000,'Short Description','',NULL,NULL,'string',NULL,'','',1,0),(263,69,NULL,NULL,'birthday',220.000,'Birthday','',NULL,NULL,'datetime',NULL,'','',1,0),(264,70,NULL,NULL,'value',222.000,'Value','',NULL,NULL,'string',NULL,'','',1,0),(265,70,NULL,NULL,'contact_type',221.000,'Type','',NULL,NULL,'string',NULL,'','',1,0),(269,69,NULL,NULL,'contacts',223.000,'Contacts','',NULL,NULL,'multilink',NULL,'{\"render_type\":\"table\",\"linking_field\":\"196\",\"linking_datatype\":\"70\"}','',1,0),(279,75,NULL,NULL,'image',233.000,'Image','Изображение',NULL,NULL,'image',NULL,'','',1,0),(280,75,NULL,NULL,'price',234.000,'Price','Цена',NULL,NULL,'float',NULL,'','',1,0),(289,1,NULL,NULL,'password',243.000,'Password','Пароль',NULL,NULL,'string',NULL,'','',1,0),(290,36,NULL,NULL,'created',4.000,'Creation date','Дата создания',NULL,NULL,'datetime',NULL,'','',0,0),(291,36,NULL,NULL,'user_id',5.000,'User','Пользователь',NULL,NULL,'link',NULL,'{\"target\":\"1\",\"prop_name\":\"user\",\"is_parent\":\"0\",\"render_type\":\"livesearch\"}','',0,0),(292,36,NULL,NULL,'site_id',6.000,'Site','Сайт',NULL,NULL,'link',NULL,'{\"target\":\"site\",\"prop_name\":\"site\",\"is_parent\":\"0\",\"render_type\":\"livesearch\"}','',0,0),(294,77,NULL,NULL,'linked_id',247.000,'Linked content id','',NULL,NULL,'link',NULL,'{\"target\":\"36\",\"prop_name\":\"content\",\"is_parent\":\"0\",\"render_type\":\"livesearch\"}','',1,0),(300,63,NULL,NULL,'currency',253.000,'Currency','',NULL,NULL,'string',NULL,'','USD',1,0),(304,23,NULL,NULL,'children',9.500,'Children','Потомки',NULL,NULL,'multilink',NULL,'{\"render_type\":\"livesearch\",\"linking_field\":\"196\",\"linking_datatype\":\"36\"}','',0,0),(305,63,NULL,NULL,'image',258.000,'Image','Изображение',NULL,NULL,'image',NULL,'','',1,0),(306,23,NULL,NULL,'description',11.000,'Description','Описание',NULL,NULL,'text',NULL,'{\"html\":\"1\",\"nl2br\":\"0\"}','',1,0),(307,23,NULL,NULL,'h1',15.000,'H1','H1',NULL,NULL,'string',431,'{\"html\":\"0\"}','',1,0),(314,80,NULL,NULL,'subject',6.000,'Subject','Заголовок',NULL,NULL,'string',NULL,'','',1,0),(315,80,NULL,NULL,'message',7.000,'Message','Сообщение',NULL,NULL,'text',NULL,'{\"html\":\"1\",\"nl2br\":\"0\"}','',1,0),(316,80,NULL,NULL,'language_id',5.000,'Language','Язык',NULL,NULL,'link',NULL,'{\"target\":\"lang\",\"prop_name\":\"language\",\"is_parent\":\"0\",\"render_type\":\"select\"}','',1,0),(317,80,NULL,NULL,'keyword',4.000,'Keyword','Ключевое слово',NULL,NULL,'string',NULL,'','',1,0),(318,81,NULL,NULL,'from',265.000,'From','От кого',NULL,NULL,'string',NULL,'','',1,0),(319,81,NULL,NULL,'bcc',266.000,'BCC','Скрытая копия',NULL,NULL,'string',NULL,'','',1,0),(320,36,NULL,NULL,'is_published',7.000,'Is published?','Публикация',NULL,NULL,'bool',NULL,'null','1',1,0),(321,36,NULL,NULL,'is_branch_published',8.000,'Is branch published?','Ветка опубликована?',NULL,NULL,'bool',NULL,'null','1',0,0),(324,19,NULL,NULL,'header',6.000,'','Заголовок',NULL,NULL,'string',NULL,'null','',1,0),(325,84,NULL,NULL,'image',271.000,'','Картинка',NULL,NULL,'image',NULL,'null','',1,0),(326,85,NULL,NULL,'name',272.000,'','Название',NULL,NULL,'text',NULL,'{\"html\":\"1\",\"nl2br\":\"1\"}','',1,0),(327,85,NULL,NULL,'image',273.000,'','Изображение',NULL,NULL,'image',NULL,'null','',1,0),(328,85,NULL,NULL,'tagline',274.000,'','Подпись',NULL,NULL,'text',NULL,'{\"html\":\"1\",\"nl2br\":\"1\"}','',1,0),(329,87,NULL,NULL,'value',7.000,'','Значение',NULL,NULL,'string',NULL,'null','',1,1),(331,36,NULL,NULL,'infoblock_id',1.500,'','Инфоблок',NULL,NULL,'link',NULL,'{\"target\":\"infoblock\",\"prop_name\":\"infoblock\",\"cascade_delete\":\"0\",\"render_type\":\"livesearch\"}','',1,0),(336,36,NULL,NULL,'type',0.000,'','Тип',NULL,NULL,'string',NULL,'',NULL,0,0),(343,36,NULL,NULL,'priority',1.000,'','Позиция',NULL,NULL,'int',NULL,'',NULL,0,0),(347,23,NULL,NULL,'full_text',16.000,'','Полный текст',NULL,NULL,'text',NULL,'{\"html\":\"1\",\"nl2br\":\"0\"}','',1,0),(355,106,NULL,NULL,'date',281.000,'','Дата',NULL,NULL,'datetime',NULL,'null','now',1,0),(357,92,NULL,NULL,'price_pre',283.000,'','Надпись до цены',NULL,NULL,'string',NULL,'null','',1,0),(358,92,NULL,NULL,'price_post',284.000,'','Надпись после цены',NULL,NULL,'string',NULL,'null','',1,0),(363,68,NULL,NULL,'tags',20.000,'','Метки',NULL,NULL,'multilink',NULL,'{\"render_type\":\"livesearch\",\"linking_field\":\"196\",\"linking_datatype\":\"77\",\"mm_field\":\"294\",\"mm_datatype\":\"78\"}','null',1,0),(366,23,NULL,NULL,'image',15.500,'','Изображение',NULL,NULL,'image',NULL,'null','',1,0),(431,23,NULL,NULL,'meta',11.500,NULL,'SEO-свойства (мета)',NULL,NULL,'group',NULL,'null',NULL,1,0),(459,23,NULL,NULL,'link_type',11.063,NULL,'Тип ссылки',NULL,NULL,'select',NULL,'{\"render_type\":\"radio_facet\"}','real',1,0),(463,23,NULL,NULL,'external_url',11.094,NULL,'Внешняя ссылка',NULL,NULL,'string',NULL,'{\"html\":\"0\"}',NULL,1,0),(464,68,NULL,196,NULL,NULL,NULL,'Раздел',NULL,NULL,NULL,NULL,'null',NULL,NULL,NULL),(467,23,NULL,NULL,'linked_page_id',11.297,NULL,'Страница, куда ссылаемся',NULL,NULL,'link',NULL,'{\"target\":\"23\",\"prop_name\":\"linked_page\",\"cascade_delete\":\"0\",\"render_type\":\"livesearch\"}',NULL,1,0),(469,24,NULL,459,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"override_select_values\":{\"1\":{\"use\":true,\"priority\":0},\"2\":{\"use\":true,\"priority\":1},\"5\":{\"use\":true,\"priority\":2},\"6\":{\"use\":false,\"priority\":3}}}','real',NULL,NULL),(472,107,NULL,NULL,'name',1.000,NULL,'Название',NULL,NULL,'string',NULL,'{\"html\":\"0\"}',NULL,1,0),(473,107,NULL,NULL,'width',2.000,NULL,'Ширина',NULL,NULL,'float',NULL,'null',NULL,1,0);
/*!40000 ALTER TABLE `fx_field` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `fx_floxim_blog_news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fx_floxim_blog_news` (
  `id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `fx_floxim_blog_news` WRITE;
/*!40000 ALTER TABLE `fx_floxim_blog_news` DISABLE KEYS */;
/*!40000 ALTER TABLE `fx_floxim_blog_news` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `fx_floxim_blog_publication`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fx_floxim_blog_publication` (
  `id` int(11) NOT NULL,
  `publish_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `fx_floxim_blog_publication` WRITE;
/*!40000 ALTER TABLE `fx_floxim_blog_publication` DISABLE KEYS */;
/*!40000 ALTER TABLE `fx_floxim_blog_publication` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `fx_floxim_corporate_contact`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fx_floxim_corporate_contact` (
  `id` int(11) NOT NULL,
  `value` varchar(255) DEFAULT NULL,
  `contact_type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `fx_floxim_corporate_contact` WRITE;
/*!40000 ALTER TABLE `fx_floxim_corporate_contact` DISABLE KEYS */;
/*!40000 ALTER TABLE `fx_floxim_corporate_contact` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `fx_floxim_corporate_person`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fx_floxim_corporate_person` (
  `id` int(11) NOT NULL,
  `full_name` varchar(255) DEFAULT NULL,
  `department` varchar(255) DEFAULT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `short_description` varchar(255) DEFAULT NULL,
  `birthday` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `fx_floxim_corporate_person` WRITE;
/*!40000 ALTER TABLE `fx_floxim_corporate_person` DISABLE KEYS */;
/*!40000 ALTER TABLE `fx_floxim_corporate_person` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `fx_floxim_corporate_project`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fx_floxim_corporate_project` (
  `id` int(11) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `fx_floxim_corporate_project` WRITE;
/*!40000 ALTER TABLE `fx_floxim_corporate_project` DISABLE KEYS */;
/*!40000 ALTER TABLE `fx_floxim_corporate_project` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `fx_floxim_corporate_vacancy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fx_floxim_corporate_vacancy` (
  `id` int(11) NOT NULL,
  `salary_from` int(11) DEFAULT NULL,
  `salary_to` int(11) DEFAULT NULL,
  `requirements` text,
  `responsibilities` text,
  `work_conditions` text,
  `currency` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `fx_floxim_corporate_vacancy` WRITE;
/*!40000 ALTER TABLE `fx_floxim_corporate_vacancy` DISABLE KEYS */;
/*!40000 ALTER TABLE `fx_floxim_corporate_vacancy` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `fx_floxim_layout_column`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fx_floxim_layout_column` (
  `id` int(11) unsigned NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `width` double DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `fx_floxim_layout_column` WRITE;
/*!40000 ALTER TABLE `fx_floxim_layout_column` DISABLE KEYS */;
/*!40000 ALTER TABLE `fx_floxim_layout_column` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `fx_floxim_main_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fx_floxim_main_content` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `priority` int(11) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `user_id` int(11) DEFAULT '0',
  `type` varchar(45) NOT NULL,
  `site_id` int(11) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `materialized_path` varchar(255) NOT NULL,
  `level` tinyint(3) unsigned NOT NULL,
  `is_published` tinyint(4) DEFAULT NULL,
  `is_branch_published` tinyint(4) DEFAULT NULL,
  `infoblock_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `materialized_path` (`materialized_path`,`level`)
) ENGINE=InnoDB AUTO_INCREMENT=3562 DEFAULT CHARSET=utf8 AVG_ROW_LENGTH=47;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `fx_floxim_main_content` WRITE;
/*!40000 ALTER TABLE `fx_floxim_main_content` DISABLE KEYS */;
INSERT INTO `fx_floxim_main_content` VALUES (3211,0,'2015-07-02 12:37:14','2015-09-28 13:51:37',0,'floxim.user.user',0,NULL,'.',1,1,1,NULL);
/*!40000 ALTER TABLE `fx_floxim_main_content` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `fx_floxim_main_linker`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fx_floxim_main_linker` (
  `id` int(11) NOT NULL,
  `linked_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `fx_floxim_main_linker` WRITE;
/*!40000 ALTER TABLE `fx_floxim_main_linker` DISABLE KEYS */;
/*!40000 ALTER TABLE `fx_floxim_main_linker` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `fx_floxim_main_mail_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fx_floxim_main_mail_template` (
  `id` int(11) NOT NULL,
  `from` varchar(255) DEFAULT NULL,
  `bcc` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `fx_floxim_main_mail_template` WRITE;
/*!40000 ALTER TABLE `fx_floxim_main_mail_template` DISABLE KEYS */;
/*!40000 ALTER TABLE `fx_floxim_main_mail_template` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `fx_floxim_main_message_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fx_floxim_main_message_template` (
  `id` int(11) NOT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `message` text,
  `language_id` int(11) DEFAULT NULL,
  `keyword` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `fx_floxim_main_message_template` WRITE;
/*!40000 ALTER TABLE `fx_floxim_main_message_template` DISABLE KEYS */;
/*!40000 ALTER TABLE `fx_floxim_main_message_template` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `fx_floxim_main_page`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fx_floxim_main_page` (
  `id` int(11) NOT NULL,
  `url` varchar(255) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` text,
  `h1` varchar(255) DEFAULT NULL,
  `full_text` text,
  `image` varchar(255) DEFAULT NULL,
  `link_type` varchar(255) DEFAULT NULL,
  `external_url` varchar(255) DEFAULT NULL,
  `linked_page_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `url` (`url`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AVG_ROW_LENGTH=62;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `fx_floxim_main_page` WRITE;
/*!40000 ALTER TABLE `fx_floxim_main_page` DISABLE KEYS */;
/*!40000 ALTER TABLE `fx_floxim_main_page` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `fx_floxim_main_text`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fx_floxim_main_text` (
  `id` int(11) NOT NULL,
  `text` mediumtext,
  `header` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AVG_ROW_LENGTH=1199;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `fx_floxim_main_text` WRITE;
/*!40000 ALTER TABLE `fx_floxim_main_text` DISABLE KEYS */;
/*!40000 ALTER TABLE `fx_floxim_main_text` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `fx_floxim_media_photo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fx_floxim_media_photo` (
  `id` int(11) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `description` text,
  `copy` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `fx_floxim_media_photo` WRITE;
/*!40000 ALTER TABLE `fx_floxim_media_photo` DISABLE KEYS */;
/*!40000 ALTER TABLE `fx_floxim_media_photo` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `fx_floxim_media_video`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fx_floxim_media_video` (
  `id` int(11) NOT NULL,
  `embed_html` text,
  `description` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `fx_floxim_media_video` WRITE;
/*!40000 ALTER TABLE `fx_floxim_media_video` DISABLE KEYS */;
/*!40000 ALTER TABLE `fx_floxim_media_video` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `fx_floxim_nav_classifier`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fx_floxim_nav_classifier` (
  `id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `fx_floxim_nav_classifier` WRITE;
/*!40000 ALTER TABLE `fx_floxim_nav_classifier` DISABLE KEYS */;
/*!40000 ALTER TABLE `fx_floxim_nav_classifier` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `fx_floxim_nav_section`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fx_floxim_nav_section` (
  `id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AVG_ROW_LENGTH=7;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `fx_floxim_nav_section` WRITE;
/*!40000 ALTER TABLE `fx_floxim_nav_section` DISABLE KEYS */;
/*!40000 ALTER TABLE `fx_floxim_nav_section` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `fx_floxim_nav_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fx_floxim_nav_tag` (
  `id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `fx_floxim_nav_tag` WRITE;
/*!40000 ALTER TABLE `fx_floxim_nav_tag` DISABLE KEYS */;
/*!40000 ALTER TABLE `fx_floxim_nav_tag` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `fx_floxim_saas_contacts_address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fx_floxim_saas_contacts_address` (
  `id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `fx_floxim_saas_contacts_address` WRITE;
/*!40000 ALTER TABLE `fx_floxim_saas_contacts_address` DISABLE KEYS */;
/*!40000 ALTER TABLE `fx_floxim_saas_contacts_address` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `fx_floxim_saas_contacts_contact`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fx_floxim_saas_contacts_contact` (
  `id` int(11) NOT NULL,
  `value` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `fx_floxim_saas_contacts_contact` WRITE;
/*!40000 ALTER TABLE `fx_floxim_saas_contacts_contact` DISABLE KEYS */;
/*!40000 ALTER TABLE `fx_floxim_saas_contacts_contact` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `fx_floxim_saas_contacts_email`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fx_floxim_saas_contacts_email` (
  `id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `fx_floxim_saas_contacts_email` WRITE;
/*!40000 ALTER TABLE `fx_floxim_saas_contacts_email` DISABLE KEYS */;
/*!40000 ALTER TABLE `fx_floxim_saas_contacts_email` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `fx_floxim_saas_contacts_link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fx_floxim_saas_contacts_link` (
  `id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `fx_floxim_saas_contacts_link` WRITE;
/*!40000 ALTER TABLE `fx_floxim_saas_contacts_link` DISABLE KEYS */;
/*!40000 ALTER TABLE `fx_floxim_saas_contacts_link` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `fx_floxim_saas_contacts_phone`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fx_floxim_saas_contacts_phone` (
  `id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `fx_floxim_saas_contacts_phone` WRITE;
/*!40000 ALTER TABLE `fx_floxim_saas_contacts_phone` DISABLE KEYS */;
/*!40000 ALTER TABLE `fx_floxim_saas_contacts_phone` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `fx_floxim_saas_content_logo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fx_floxim_saas_content_logo` (
  `id` int(11) NOT NULL,
  `name` text,
  `image` varchar(255) DEFAULT NULL,
  `tagline` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `fx_floxim_saas_content_logo` WRITE;
/*!40000 ALTER TABLE `fx_floxim_saas_content_logo` DISABLE KEYS */;
/*!40000 ALTER TABLE `fx_floxim_saas_content_logo` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `fx_floxim_saas_content_pic_text`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fx_floxim_saas_content_pic_text` (
  `id` int(11) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `fx_floxim_saas_content_pic_text` WRITE;
/*!40000 ALTER TABLE `fx_floxim_saas_content_pic_text` DISABLE KEYS */;
/*!40000 ALTER TABLE `fx_floxim_saas_content_pic_text` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `fx_floxim_saas_content_reviews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fx_floxim_saas_content_reviews` (
  `id` int(11) unsigned NOT NULL,
  `date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `fx_floxim_saas_content_reviews` WRITE;
/*!40000 ALTER TABLE `fx_floxim_saas_content_reviews` DISABLE KEYS */;
/*!40000 ALTER TABLE `fx_floxim_saas_content_reviews` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `fx_floxim_saas_content_service`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fx_floxim_saas_content_service` (
  `id` int(11) NOT NULL,
  `price_pre` varchar(255) DEFAULT NULL,
  `price_post` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `fx_floxim_saas_content_service` WRITE;
/*!40000 ALTER TABLE `fx_floxim_saas_content_service` DISABLE KEYS */;
/*!40000 ALTER TABLE `fx_floxim_saas_content_service` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `fx_floxim_saas_saas_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fx_floxim_saas_saas_user` (
  `id` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `fx_floxim_saas_saas_user` WRITE;
/*!40000 ALTER TABLE `fx_floxim_saas_saas_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `fx_floxim_saas_saas_user` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `fx_floxim_shop_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fx_floxim_shop_product` (
  `id` int(11) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `price` double DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `fx_floxim_shop_product` WRITE;
/*!40000 ALTER TABLE `fx_floxim_shop_product` DISABLE KEYS */;
/*!40000 ALTER TABLE `fx_floxim_shop_product` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `fx_floxim_user_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fx_floxim_user_user` (
  `id` int(11) NOT NULL,
  `email` char(255) NOT NULL,
  `login` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `registration_code` varchar(45) DEFAULT NULL,
  `avatar` varchar(255) DEFAULT NULL,
  `forum_messages` int(11) NOT NULL DEFAULT '0',
  `pa_balance` double NOT NULL DEFAULT '0',
  `auth_hash` varchar(50) NOT NULL DEFAULT '',
  `is_admin` tinyint(4) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `User_ID` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AVG_ROW_LENGTH=104;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `fx_floxim_user_user` WRITE;
/*!40000 ALTER TABLE `fx_floxim_user_user` DISABLE KEYS */;
INSERT INTO `fx_floxim_user_user` VALUES (3211,'dubr.cola@gmail.com','','Админ',NULL,NULL,0,0,'',1,'20EAfcH0JSFQY');
/*!40000 ALTER TABLE `fx_floxim_user_user` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `fx_infoblock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fx_infoblock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_infoblock_id` int(11) DEFAULT '0',
  `site_id` int(11) DEFAULT NULL,
  `page_id` int(10) unsigned DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `controller` varchar(50) NOT NULL,
  `action` varchar(50) NOT NULL,
  `params` text NOT NULL,
  `scope` text NOT NULL,
  `scope_type` enum('one_page','all_pages','custom','') NOT NULL,
  `scope_id` int(11) DEFAULT NULL,
  `is_preset` tinyint(3) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `page_id` (`page_id`)
) ENGINE=InnoDB AUTO_INCREMENT=76 DEFAULT CHARSET=utf8 AVG_ROW_LENGTH=210;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `fx_infoblock` WRITE;
/*!40000 ALTER TABLE `fx_infoblock` DISABLE KEYS */;
INSERT INTO `fx_infoblock` VALUES (32,0,NULL,NULL,'Текст+картинка','floxim_saas.content.pic_text','list_infoblock','{\"parent_type\":\"current_page\"}','','one_page',NULL,1);
/*!40000 ALTER TABLE `fx_infoblock` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `fx_infoblock_visual`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fx_infoblock_visual` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `infoblock_id` int(10) unsigned NOT NULL,
  `layout_id` int(10) unsigned NOT NULL,
  `wrapper` varchar(255) NOT NULL,
  `wrapper_visual` text NOT NULL,
  `template` varchar(255) NOT NULL,
  `template_visual` text NOT NULL,
  `area` varchar(50) NOT NULL,
  `priority` decimal(6,3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `infoblock_id` (`infoblock_id`,`layout_id`)
) ENGINE=InnoDB AUTO_INCREMENT=87 DEFAULT CHARSET=utf8 AVG_ROW_LENGTH=138;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `fx_infoblock_visual` WRITE;
/*!40000 ALTER TABLE `fx_infoblock_visual` DISABLE KEYS */;
INSERT INTO `fx_infoblock_visual` VALUES (31,32,15,'theme.floxim_saas.squares:wrapper_squares','{\"with_header\":\"1\",\"with_link\":\"0\"}','theme.floxim_saas.squares:floxim_saas_content_pic_text_list_high_pic','null','content',0.500);
/*!40000 ALTER TABLE `fx_infoblock_visual` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `fx_lang`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fx_lang` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `en_name` varchar(100) NOT NULL,
  `native_name` varchar(100) NOT NULL,
  `lang_code` varchar(5) NOT NULL,
  `declension` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `lang_code` (`lang_code`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `fx_lang` WRITE;
/*!40000 ALTER TABLE `fx_lang` DISABLE KEYS */;
INSERT INTO `fx_lang` VALUES (1,'English','English','en',''),(9,'Russian','Русский','ru','{\"singular\":{\"description\":\"\\u0415\\u0434\\u0438\\u043d\\u0441\\u0442\\u0432\\u0435\\u043d\\u043d\\u043e\\u0435 \\u0447\\u0438\\u0441\\u043b\\u043e\",\"values\":{\"nom\":{\"name\":\"\\u0418\\u043c\\u0435\\u043d\\u0438\\u0442\\u0435\\u043b\\u044c\\u043d\\u044b\\u0439\",\"description\":\"\\u041a\\u0442\\u043e? \\u0427\\u0442\\u043e?\",\"placeholder\":\"\\u041d\\u043e\\u0432\\u043e\\u0441\\u0442\\u044c\",\"required\":true},\"gen\":{\"name\":\"\\u0420\\u043e\\u0434\\u0438\\u0442\\u0435\\u043b\\u044c\\u043d\\u044b\\u0439\",\"description\":\"\\u041a\\u043e\\u0433\\u043e? \\u0427\\u0435\\u0433\\u043e?\",\"placeholder\":\"\\u041d\\u043e\\u0432\\u043e\\u0441\\u0442\\u0438\",\"required\":true},\"dat\":{\"name\":\"\\u0414\\u0430\\u0442\\u0435\\u043b\\u044c\\u043d\\u044b\\u0439\",\"description\":\"\\u041a\\u043e\\u043c\\u0443? \\u0427\\u0435\\u043c\\u0443?\",\"placeholder\":\"\\u041d\\u043e\\u0432\\u043e\\u0441\\u0442\\u0438\"},\"acc\":{\"name\":\"\\u0412\\u0438\\u043d\\u0438\\u0442\\u0435\\u043b\\u044c\\u043d\\u044b\\u0439\",\"description\":\"\\u041a\\u043e\\u0433\\u043e? \\u0427\\u0442\\u043e?\",\"placeholder\":\"\\u041d\\u043e\\u0432\\u043e\\u0441\\u0442\\u044c\",\"required\":true},\"inst\":{\"name\":\"\\u0422\\u0432\\u043e\\u0440\\u0438\\u0442\\u0435\\u043b\\u044c\\u043d\\u044b\\u0439\",\"description\":\"\\u041a\\u0435\\u043c? \\u0427\\u0435\\u043c?\",\"placeholder\":\"\\u041d\\u043e\\u0432\\u043e\\u0441\\u0442\\u044c\\u044e\"},\"prep\":{\"name\":\"\\u041f\\u0440\\u0435\\u0434\\u043b\\u043e\\u0436\\u043d\\u044b\\u0439\",\"description\":\"\\u041e \\u043a\\u043e\\u043c? \\u041e \\u0447\\u0451\\u043c?\",\"placeholder\":\"\\u041d\\u043e\\u0432\\u043e\\u0441\\u0442\\u0438\"}}},\"plural\":{\"description\":\"\\u041c\\u043d\\u043e\\u0436\\u0435\\u0441\\u0442\\u0432\\u0435\\u043d\\u043d\\u043e\\u0435 \\u0447\\u0438\\u0441\\u043b\\u043e\",\"values\":{\"nom\":{\"name\":\"\\u0418\\u043c\\u0435\\u043d\\u0438\\u0442\\u0435\\u043b\\u044c\\u043d\\u044b\\u0439\",\"description\":\"\\u041a\\u0442\\u043e? \\u0427\\u0442\\u043e?\",\"placeholder\":\"\\u041d\\u043e\\u0432\\u043e\\u0441\\u0442\\u0438\",\"required\":true},\"gen\":{\"name\":\"\\u0420\\u043e\\u0434\\u0438\\u0442\\u0435\\u043b\\u044c\\u043d\\u044b\\u0439\",\"description\":\"\\u041a\\u043e\\u0433\\u043e? \\u0427\\u0435\\u0433\\u043e?\",\"placeholder\":\"\\u041d\\u043e\\u0432\\u043e\\u0441\\u0442\\u0435\\u0439\",\"required\":true},\"dat\":{\"name\":\"\\u0414\\u0430\\u0442\\u0435\\u043b\\u044c\\u043d\\u044b\\u0439\",\"description\":\"\\u041a\\u043e\\u043c\\u0443? \\u0427\\u0435\\u043c\\u0443?\",\"placeholder\":\"\\u041d\\u043e\\u0432\\u043e\\u0441\\u0442\\u044f\\u043c\"},\"acc\":{\"name\":\"\\u0412\\u0438\\u043d\\u0438\\u0442\\u0435\\u043b\\u044c\\u043d\\u044b\\u0439\",\"description\":\"\\u041a\\u043e\\u0433\\u043e? \\u0427\\u0442\\u043e?\",\"placeholder\":\"\\u041d\\u043e\\u0432\\u043e\\u0441\\u0442\\u0438\",\"required\":true},\"inst\":{\"name\":\"\\u0422\\u0432\\u043e\\u0440\\u0438\\u0442\\u0435\\u043b\\u044c\\u043d\\u044b\\u0439\",\"description\":\"\\u041a\\u0435\\u043c? \\u0427\\u0435\\u043c?\",\"placeholder\":\"\\u041d\\u043e\\u0432\\u043e\\u0441\\u0442\\u044f\\u043c\\u0438\"},\"prep\":{\"name\":\"\\u041f\\u0440\\u0435\\u0434\\u043b\\u043e\\u0436\\u043d\\u044b\\u0439\",\"description\":\"\\u041e \\u043a\\u043e\\u043c? \\u041e \\u0447\\u0451\\u043c?\",\"placeholder\":\"\\u041d\\u043e\\u0432\\u043e\\u0441\\u0442\\u044f\\u0445\"}}}}');
/*!40000 ALTER TABLE `fx_lang` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `fx_lang_string`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fx_lang_string` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dict` varchar(45) DEFAULT NULL,
  `string` text,
  `lang_en` text,
  `lang_ru` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1209 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `fx_lang_string` WRITE;
/*!40000 ALTER TABLE `fx_lang_string` DISABLE KEYS */;
INSERT INTO `fx_lang_string` VALUES (1,'component_section','Show path to the current page','Show path to the current page','Отображает путь до текущей страницы в структуре сайта'),(2,'component_section','Bread crumbs','Bread crumbs','Хлебные крошки'),(3,'component_section','Subsection','Subsection','Подраздел'),(4,'component_section','Show for all items','Show for all items','Показывать у всех'),(5,'component_section','Show for the active item','Show for the active item','Показывать у активного'),(6,'component_section','Don\'t show','Don\'t show','Не показывать'),(7,'component_section','Subsections','Subsections','Подразделы'),(8,'component_section','Navigation','Navigation','Меню'),(9,'system','File is not writable','File is not writable','Не могу произвести запись в файл'),(10,'controller_component','Show entries by filter','Show entries by filter','Выводит записи по произвольному фильтру'),(11,'controller_component','Show entries from the specified section','Show entries from the specified section','Выводит список записей из указанного раздела'),(12,'controller_component','List','List','Список'),(13,'controller_component','Show single entry','Show single entry','Выводит отдельную запись'),(14,'controller_component','Entry','Entry','Запись'),(15,'controller_component','From specified section','From specified section','Указать раздел явно'),(16,'controller_component','From all sections','From all sections','Из любого раздела'),(17,'controller_component','Choose section','Choose section','Выбрать родителя'),(18,'controller_component','Random','Random','Произвольный'),(19,'controller_component','The infoblock owner section','The infoblock owner section','Страница, куда прицеплен инфоблок'),(20,'controller_component','Current page','Current page','Текущая страница'),(21,'controller_component','Parent','Parent','Родитель'),(22,'controller_component','Ascending','Ascending','По возрастанию'),(23,'controller_component','Descending','Descending','По убыванию'),(24,'controller_component','Order','Order','Порядок'),(25,'controller_component','Sorting','Sorting','Сортировка'),(26,'controller_component','Manual','Manual','Ручная'),(27,'controller_component','Created','Created','Дата создания'),(28,'controller_component','Show pagination?','Show pagination?','Разбивать на страницы?'),(29,'controller_component','How many entries to display','How many entries to display','Сколько выводить'),(30,'controller_layout','Sign in','Sign in','Вход'),(31,'system','Add infoblock','Add infoblock','Добавить инфоблок'),(32,'system','Link','Link','Ссылка'),(33,'system','Picture','Picture','Картинка'),(34,'system','Elements','Elements','Элементы'),(35,'system','Classifier','Classifier','Классификатор'),(36,'system','Manually','Manually','Вручную'),(37,'system','Source','Source','Источник'),(38,'system','Show like','Show like','Показывать как'),(39,'system','Current file:','Current file:','Текущий файл:'),(40,'system','replace newline to br','Replace newline with &lt;br /&gt;','Заменять перенос строки на &lt;br&gt;<br>'),(41,'system','allow HTML tags','Allow HTML tags','Разрешить html-теги'),(42,'system','Related type','Related type','Связанный тип'),(43,'system','Bind value to the parent','Bind value to the parent','Привязать значение к родителю'),(44,'system','Key name for the property','Key name for the property','Ключ для свойства'),(45,'system','Links to','Links to','Куда ссылается'),(46,'system','Enter the name of the site','Enter the name of the site','Укажите название сайта'),(47,'system','Priority','Priority','Приоритет'),(49,'system','This keyword is used by the component','This keyword is used by the component','Такой keyword уже используется компоненте'),(50,'system','Keyword can only contain letters, numbers, symbols, \"hyphen\" and \"underscore\"','Keyword can only contain letters, numbers, symbols, \"hyphen\" and \"underscore\"','Keyword может содержать только буквы, цифры, символы \"дефис\" и \"подчеркивание\"'),(51,'system','Specify component keyword','Specify component keyword','Укажите keyword компонента'),(52,'system','Component name can not be empty','Component name can not be empty','Название компонента не может быть пустым'),(53,'system','Specify field description','Specify field description','Укажите описание поля'),(54,'system','This field already exists','This field already exists','Такое поле уже существует'),(55,'system','This field is reserved','This field is reserved','Данное поле зарезервировано'),(56,'system','Field name can contain only letters, numbers, and the underscore character','Field name can contain only letters, numbers, and the underscore character','Имя поля может содержать только латинские буквы, цифры и знак подчеркивания'),(57,'system','name','name','название'),(58,'system','Specify field name','Specify field name','Укажите название поля'),(59,'system','This keyword is used by widget','This keyword is used by widget','Такой keyword уже используется в виджете'),(60,'system','Keyword can contain only letters and numbers','Keyword can contain only letters and numbers','Keyword может сожержать только буквы и цифры'),(61,'system','Enter the keyword of widget','Enter the keyword of widget','Укажите keyword виджета'),(62,'system','Specify the name of the widget','Specify the name of the widget','Укажите название виджета'),(63,'system','You are about to install:','You are about to install:','Вы собираетесь установить:'),(64,'system','Preview','Preview','Предпросмотр'),(65,'system','Layout','Layout','Макет'),(66,'system','Show when the site is off','Show when the site is off','Показывать, когда сайт выключен'),(67,'system','Cover Page','Cover Page','Титульная страница'),(68,'system','Prevent indexing','Prevent indexing','Запретить индексирование'),(69,'system','The contents of robots.txt','The contents of robots.txt','Содержимое robots.txt'),(70,'system','Site language','Site language','Язык сайта'),(71,'system','Aliases','Aliases','Зеркала'),(72,'system','Domain','Domain','Домен'),(73,'system','Site name','Site name','Название сайта'),(74,'system','Enabled','Enabled','Включен'),(75,'system','System','System','Системные'),(76,'system','Main','Main','Основные'),(77,'system','any','any','любое'),(78,'system','vertical','vertical','вертикальное'),(79,'system','Menu','Menu','Меню'),(80,'system','Direction','Direction','Направление'),(81,'system','Required','Required','Обязательный'),(82,'system','Block','Block','Блок'),(83,'system','Blocks','Blocks','Блоки'),(84,'system','Sites','Sites','Сайты'),(85,'system','Design','Design','Блоки'),(86,'system','Settings','Settings','Настройки'),(87,'system','Site map','Site map','Карта сайта'),(88,'system','Site not found','Site not found','Сайт не найден'),(89,'system','Page not found','Page not found','Страница не найдена'),(90,'system','Error creating a temporary file','Error creating a temporary file','Ошибка при создании временного файла'),(91,'system','Create a new site','Create a new site','Добавление нового сайта'),(92,'system','Add new site','Add new site','Новый сайт'),(93,'system','New','New','Новый'),(94,'system','Export','Export','Экспорт'),(95,'system','for mobile devices','for mobile devices','для мобильный устройств'),(96,'system','Language:','Language:','Язык:'),(97,'system','Description','Description','Описание'),(98,'system','Group','Group','Группа'),(99,'system','Another group','Another group','Другая группа'),(100,'system','Name of entity created by the component','Name of entity created by the component','Название сущности, создаваемой компонентом'),(101,'system','Component name','Component name','Название компонента'),(102,'system','Keyword:','Keyword:','Ключевое слово:'),(103,'system','--no--','--no--','--нет--'),(104,'system','Parent component','Parent component','Компонент-родитель'),(105,'system','default','default','по умолчанию'),(106,'system','Components','Components','Компоненты'),(107,'system','Widgets','Widgets','Виджеты'),(108,'system','Keyword','Keyword','Ключевое слово'),(109,'system','File','File','Файл'),(110,'system','Fields','Fields','Поля'),(111,'system','Install from FloximStore','Install from FloximStore','установить с FloximStore'),(112,'system','import','import','импортировать'),(113,'system','Layout of inside page','Layout of inside page','Макет внутренней страницы'),(114,'system','Cover Page Layout','Cover Page Layout','Макет титульной страницы'),(115,'system','Sign out','Sign out','Выход'),(116,'system','Apply the current','Apply the current','Применить текущий'),(117,'system','Colors','Colors','Расцветка'),(118,'system','Layout not found','Layout not found','Макет не найден'),(119,'system','Enter the layout name','Enter the layout name','Укажите название макета'),(120,'system','Layout name','Layout name','Название макета'),(121,'system','Export to file','Export to file','Экспортировать в файл'),(122,'system','No files','No files','Нет файлов'),(123,'system','Layouts','Layouts','Макеты'),(124,'system','Unable to create directory','Unable to create directory','Не удалось создать каталог'),(125,'system','Adding a layout design','Adding a layout design','Добавление макета дизайна'),(126,'system','Import layout design','Import layout design','Импорт макета дизайна'),(127,'system','empty','empty','пустой'),(128,'system','Used on','Used on','Используется на сайтах'),(129,'system','Repeated','Repeated','Повторено'),(130,'system','Cancelled','Cancelled','Отменено'),(131,'system','Header sent','Header sent','Посылаемый заголовок'),(132,'system','New url','New url','Новый url'),(133,'system','Old url','Old url','Старый url'),(134,'system','Changing the transfer rule','Changing the transfer rule','Изменение правила переадресации'),(135,'system','Adding forwarding rules','Adding forwarding rules','Добавление правила переадресации'),(136,'system','Header','Header','Заголовок'),(137,'system','Layouts can not be deleted','Layouts can not be deleted','Удалять лейауты нельзя!'),(138,'system','Unbind/Hide','Unbind/Hide','Отвязать/скрыть'),(139,'system','Delete','Delete','Удалить'),(140,'system','The infoblock contains some content','The infoblock contains some content','Инфоблок содержит контент'),(141,'system','items. What should we do with them?','items. What should we do with them?',' шт. Что с ним делать?'),(142,'system','I am REALLY shure','I am REALLY shure','Будет удалено куча всего, я понимаю последствия'),(143,'system','Block wrapper template','Block wrapper template','Оформление блока'),(144,'system','Template','Template','Шаблон'),(145,'system','Auto select','Auto select','Автовыбор'),(146,'system','With no wrapper','With no wrapper','Без оформления'),(147,'system','On the page and it\'s children','On the page and it\'s children','На этой и на вложенных'),(148,'system','Only on children','Only on children','Только на вложенных страницах'),(149,'system','Only on the page','Only on the page','Только на этой странице'),(150,'system','Page','Page','Страница'),(151,'system','On all pages','On all pages','На всех страницах'),(152,'system','Remove this rule','Remove this rule','Удалить это правило'),(153,'system','Create a new rule','Create a new rule','Создать новое правило'),(154,'system','Update','Update','Обновить'),(155,'system','Create','Create','Создать'),(156,'system','Page layout','Page layout','Выбор шаблона страницы'),(157,'system','Infoblock settings','Infoblock settings','Настройка инфоблока'),(158,'system','Where to show','Where to show','Где показывать'),(159,'system','How to show','How to show','Как показывать'),(160,'system','Block name','Block name','Название блока'),(161,'system','What to show','What to show','Что показывать'),(162,'system','Widget','Widget','Виджет'),(163,'system','Next','Next','Продолжить'),(164,'system','Install from Store','Install from Store','Установить с Store'),(165,'system','Adding infoblock','Adding infoblock','Добавляем блок'),(166,'system','Type','Type','Тип'),(167,'system','Action','Action','Действие'),(169,'system','Component','Component','Компонент'),(170,'system','Single entry','Single entry','Отдельный объект'),(171,'system','Mirror','Mirror','Mirror'),(173,'system','Change password','Change password','Сменить пароль'),(175,'system','Download from FloximStore','Download from FloximStore','Скачать с FloximStore'),(176,'system','Download file','Download file','Cкачать файл'),(177,'system','Upload file','Upload file','Закачать файл'),(178,'system','Permissions','Permissions','Права'),(179,'system','Select parent block','Select parent block','выделить блок'),(180,'system','Site layout','Site layout','Сменить макет сайта'),(181,'system','Page design','Page design','Дизайн страницы'),(182,'system','Development','Development','Разработка'),(183,'system','Administration','Administration','Администрирование'),(184,'system','Tools','Tools','Инструменты'),(185,'system','Users','Users','Пользователи'),(186,'system','Site','Site','Сайт'),(187,'system','Management','Management','Управление'),(188,'system','Default value','Default value','Значение по умолчанию'),(189,'system','Field can be used for searching','Field can be used for searching','Возможен поиск по полю'),(191,'system','Field not found','Field not found','Поле не найдено'),(192,'system','Field is available for','Field is available for','Поле доступно'),(193,'system','anybody','anybody','всем'),(194,'system','admins only','admins only','только админам'),(195,'system','nobody','nobody','никому'),(196,'system','Field type','Field type','Тип поля'),(197,'system','Field keyword','Field keyword','Название на латинице'),(199,'system','New widget','New widget','Новый виджет'),(200,'system','Widget size','Widget size','Размер виджета'),(201,'system','Mini Block','Mini Block','Миниблок'),(202,'system','Narrow','Narrow','Узкий'),(203,'system','Wide','Wide','Широкий'),(204,'system','Narrowly wide','Narrowly wide','Узко-широкий'),(205,'system','Icon to be used','Icon to be used','Используемая иконка'),(206,'system','This icon is used by default','This icon is used by default','эта иконка используется по умолчанию'),(207,'system','This icon is icon.png file in the directory widget','This icon is icon.png file in the directory widget','эта иконка находится в файле icon.png в директории виджета'),(208,'system','This icon is selected from a list of icons','This icon is selected from a list of icons','эта иконка выбрана из списка иконок'),(209,'system','Enter the widget name','Enter the widget name','Введите название виджета'),(210,'system','Specify the name','Specify the name','Укажите название'),(211,'system','Edit User Group','Edit User Group','Изменение группы пользователей'),(212,'system','Add User Group','Add User Group','Добавление группы пользователей'),(213,'system','New Group','New Group','Новая группа'),(214,'system','Assign the right director','Assign the right director','Присвоить право директора'),(215,'system','The first version has just the right director','The first version has just the right director','В первой версии есть только право Директор'),(216,'system','There are no rules','There are no rules','Нет никак прав'),(217,'system','Permission','Permission','Право'),(218,'system','Content edit','Content edit','Редактирование контента'),(219,'system','Avatar','Avatar','Аватар'),(220,'system','Nick','Nick','Имя на сайте'),(221,'system','Confirm password','Confirm password','Пароль еще раз'),(222,'system','Password','Password','Пароль'),(223,'system','Login','Login','Логин'),(224,'system','Groups','Groups','Группы'),(225,'system','Passwords do not match','Passwords do not match','Пароли не совпадают'),(226,'system','Password can\'t be empty','Password can\'t be empty','Пароль не может быть пустым'),(227,'system','Fill in with the login','Fill in with the login','Заполните поле с логином'),(228,'system','Please select at least one group','Please select at least one group','Выберите хотя бы одну группу'),(229,'system','Add User','Add User','Добавление пользователя'),(230,'system','publications in','publications in','публикации в'),(231,'system','Select objects','Select objects','Выберите объекты'),(232,'system','publish:','publish:','опубликовал:'),(234,'system','friends, send message','friends, send message','друзья, отправить сообщение'),(235,'system','registred:','registred:','зарегистрирован:'),(236,'system','Activity','Activity','Активность'),(237,'system','Registration data','Registration data','Регистрационные данные'),(238,'system','Rights management','Rights management','Управление правами'),(239,'system','Password and verification do not match.','Password and verification do not match.','Пароль и подтверждение не совпадают.'),(240,'system','Password is too short. The minimum length of the password','Password is too short. The minimum length of the password','Пароль слишком короткий. Минимальная длина пароля'),(241,'system','Enter the password','Enter the password','Введите пароль.'),(242,'system','This login is already in use','This login is already in use','Такой логин уже используется'),(243,'system','Error: can not find information block with users.','Error: can not find information block with users.','Ошибка: не найден инфоблок с пользователями.'),(244,'system','Self-registration is prohibited.','Self-registration is prohibited.','Самостоятельная регистрация запрещена.'),(245,'system','Can not find <? ​​Php class file','Can not find <? ​​Php class file','Не могу найти <?php в файле класса'),(246,'system','Syntax error in the component class','Syntax error in the component class','Синтаксическая ошибка в классе компонента'),(247,'system','Syntax error in function','Syntax error in function','Синтаксическая ошибка в функции'),(248,'system','Profile','Profile','Профиль'),(249,'system','User not found','User not found','Пользователь не найден'),(250,'system','List not found','List not found','Список не найден'),(252,'system','Widget not found','Widget not found','Виджет не найден'),(253,'system','Component not found','Component not found','Компонент не найден'),(254,'system','Modules','Modules','Модули'),(255,'system','All sites','Sites','Список сайтов'),(256,'system','Unable to connect to server','Unable to connect to server','Не удалось соединиться с сервером'),(257,'system','Override the settings in the class','Override the settings in the class','Переопределите метод settings в своем классе'),(258,'system','Configuring the','Configuring the','Настройка модуля'),(260,'system','Saved','Saved','Сохранено'),(261,'system','Could not open file!','Could not open file!','Не получилось открыть файл!'),(262,'system','Error when downloading a file','Error when downloading a file','Ошибка при закачке файла'),(263,'system','Enter the file','Enter the file','Укажите файл'),(264,'system','Not all fields are transferred!','Not all fields are transferred!','Не все поля переданы!'),(265,'system','Error Deleting File','Error Deleting File','Ошибка при удалении файла'),(266,'system','Error when changing the name','Error when changing the name','Ошибка при изменении имени'),(267,'system','Error when permission','Error when permission','Ошибка при изменении прав доступа'),(268,'system','Set permissions','Set permissions','Задайте права доступа'),(269,'system','Enter the name','Enter the name','Укажите имя'),(270,'system','Edit the file/directory','Edit the file/directory','Правка файла/директории'),(271,'system','View the contents','View the contents','Просмотр содержимого'),(272,'system','Execution','Execution','Выполнение'),(273,'system','Writing','Writing','Запись'),(274,'system','Reading','Reading','Чтение'),(275,'system','Permissions for the rest','Permissions for the rest','Права для остальных'),(276,'system','Permissions for the group owner','Permissions for the group owner','Права для группы-владельца'),(277,'system','Permissions for the user owner','Permissions for the user owner','Права для пользователя-владельца'),(278,'system','Do not pass the file name!','Do not pass the file name!','Не передано имя файла!'),(279,'system','An error occurred while creating the file/directory','An error occurred while creating the file/directory','Ошибка при создании файла/каталога'),(280,'system','Not all fields are transferred','Not all fields are transferred','Не все поля переданы'),(281,'system','Enter the name of the file/directory','Enter the name of the file/directory','Укажите имя файла/каталога'),(282,'system','Create a new file/directory','Create a new file/directory','Создание нового файла/директории'),(283,'system','Name of file/directory','Name of file/directory','Имя файла/каталога'),(284,'system','What we create','What we create','Что создаём'),(285,'system','directory','directory','каталог'),(286,'system','Writing to file failed','Writing to file failed','Не удалась запись в файл'),(287,'system','Reading of file failed','Reading of file failed','Не удалось прочитать файл!'),(288,'system','Gb','Gb','Гб'),(289,'system','Mb','Mb','Мб'),(290,'system','Kb','Kb','Кб'),(291,'system','byte','byte','байт'),(292,'system','Parent directory','Parent directory','родительский каталог'),(293,'system','Size','Size','Размер'),(294,'system','File-manager','File-manager','Файл-менеджер'),(295,'system','Invalid action','Invalid action','Неверное действие'),(296,'system','Invalid user id','Invalid user id','Неверный id пользователя'),(297,'system','Invalid code','Invalid code','Неверный код'),(298,'system','Your account has been created.','Your account has been created.','Ваш аккаунт активирован.'),(299,'system','Your e-mail address is confirmed. Wait for the verification and account activation by the administrator.','Your e-mail address is confirmed. Wait for the verification and account activation by the administrator.','Ваш адрес e-mail подтвержден. Дождитесь проверки и активации учетной записи администратором.'),(300,'system','Invalid confirmation code registration.','Invalid confirmation code registration.','Неверный код подтверждения регистрации.'),(301,'system','Not passed the verification code registration.','Not passed the verification code registration.','Не передан код подтверждения регистрации.'),(302,'system','Action after the first authorization','Action after the first authorization','Действие после первой авторизации'),(303,'system','Group, which gets the user after login','Group, which gets the user after login','Группы, куда попадет пользователь после авторизации'),(304,'system','Facebook data','Facebook data','Данные facebook'),(305,'system','User fields','User fields','Поля пользователя'),(306,'system','Complies fields','Complies fields','Соответсвие полей'),(307,'system','enable authentication with facebook','enable authentication with facebook','включить авторизацию через facebook'),(308,'system','Twitter data','Twitter data','Данные twiiter'),(309,'system','enable authentication with twitter','enable authentication with twitter','включить авторизацию через твиттер'),(310,'system','The minimum length of the password must be an integer.','The minimum length of the password must be an integer.','Минимальная длина пароля должна быть целым числом.'),(311,'system','The time during which the user is online, can be an integer greater than 0.','The time during which the user is online, can be an integer greater than 0.','Время, в течение которого пользователь считается online, должно быть целым числом больше 0.'),(312,'system','nvalid address format of e-mail.','nvalid address format of e-mail.','Неверный формат адреса e-mail.'),(313,'system','You have not selected any of the member.','You have not selected any of the member.','Вы не выбрали ни одной группы для зарегистрированных пользователей.'),(314,'system','HTML-letter','HTML-letter','HTML-письмо'),(315,'system','Letter body','Letter body','Тело письма'),(316,'system','Letter header','Letter header','Заголовок письма'),(317,'system','Restore the default form','Restore the default form','Восстановить форму по умолчанию'),(318,'system','Component \"Private Messages\"','Component \"Private Messages\"','Компонент \"Личные сообщения\"'),(319,'system','Component \"Users\"','Component \"Users\"','Компонент \"Пользователи\"'),(320,'system','Allow users to add enemies','Allow users to add enemies','Разрешить добавлять пользователей во враги'),(321,'system','Friends and enemies','Friends and enemies','Друзья и враги'),(322,'system','Allow users to add as friend','Allow users to add as friend','Разрешить добавлять пользователей в друзья'),(323,'system','Notify the user by e-mail about the new message','Notify the user by e-mail about the new message','Оповещать пользователя по e-mail о новом сообщении'),(324,'system','Private messages','Private messages','Личные сообщения'),(325,'system','Allow to send private messages','Allow to send private messages','Разрешить отправлять личные сообщения'),(326,'system','User authentication after the confirm','User authentication after the confirm','Авторизация пользователя сразу после подтверждения'),(327,'system','E-mail the administrator to send alerts','E-mail the administrator to send alerts','E-mail администратора для отсылки оповещений'),(328,'system','Send a letter to the manager when a user logs','Send a letter to the manager when a user logs','Отправлять письмо администратору при регистрации пользователя'),(329,'system','Moderated by the administrator','Moderated by the administrator','Премодерация администратором'),(330,'system','Require confirmation by e-mail','Require confirmation by e-mail','Требовать подтверждение через e-mail'),(331,'system','Group to which the user will get after registration','Group to which the user will get after registration','Группы, куда попадёт пользователь после регистрации'),(332,'system','Enable self-registration','Enable self-registration','Разрешить самостоятельную регистрацию'),(333,'system','Registration','Registration','Регистрация'),(334,'system','Bind users to sites','Bind users to sites','Привязывать пользователей к сайтам'),(335,'system','Deny yourself to recover your password','Deny yourself to recover your password','Запретить самостоятельно восстанавливать пароль'),(336,'system','General Settings','General Settings','Общие настройки'),(337,'system','Do not show the form of a failed login attempt','Do not show the form of a failed login attempt','Не показывать форму при неудачной попытке авторизации'),(338,'system','Restored','Restored','Восстановлено'),(339,'system','Nonexistent tab!','Nonexistent tab!','Несуществующая вкладка!'),(340,'system','Login through external services','Login through external services','Авторизация через внешние сервисы'),(341,'system','Email templates','Email templates','Шаблоны писем'),(342,'system','General','General','Общие'),(343,'system','Password restore','Password restore','Восстановление пароля'),(344,'system','Registration confirm','Registration confirm','Подтверждение регистрации'),(345,'system','Now you will be taken to the login page.','Now you will be taken to the login page.','Сейчас вы будете переброшены на страницу авторизации.'),(346,'system','Click here if you do not want to wait.','Click here if you do not want to wait.','Нажмите, если не хотите ждать.'),(347,'system','Login via twitter disabled','Login via twitter disabled','Авторизация через twitter запрещена'),(348,'system','Login via facebook disabled','Login via facebook disabled','Авторизация через facebook запрещена'),(349,'system','FX_ADMIN_FIELD_STRING','String','Строка'),(350,'system','FX_ADMIN_FIELD_INT','Integer','Целое число'),(352,'system','FX_ADMIN_FIELD_SELECT','Options list','Список'),(353,'system','FX_ADMIN_FIELD_BOOL','Boolean','Логическая переменная'),(354,'system','FX_ADMIN_FIELD_FILE','File','Файл'),(355,'system','FX_ADMIN_FIELD_FLOAT','Float number','Дробное число'),(356,'system','FX_ADMIN_FIELD_DATETIME','Date and time','Дата и время'),(357,'system','FX_ADMIN_FIELD_COLOR','Color','Цвет'),(359,'system','FX_ADMIN_FIELD_IMAGE','Image','Изображение'),(360,'system','FX_ADMIN_FIELD_MULTISELECT','Multiple select','Мультисписок'),(361,'system','FX_ADMIN_FIELD_LINK','Link to another object','Связь с другим объектом'),(362,'system','FX_ADMIN_FIELD_MULTILINK','Multiple link','Множественная связь'),(363,'system','FX_ADMIN_FIELD_TEXT','Text','Текст'),(375,'system','add','add','добавить'),(376,'system','edit','edit','Редактировать'),(377,'system','on','on','on'),(378,'system','off','off','off'),(381,'system','Render type','Render type','Render type'),(382,'system','Live search','Live search','Live search'),(383,'system','Simple select','Simple select','Simple select'),(384,'system','-Any-','-Any-','Любой'),(385,'system','Only on pages of type','Only on pages of type','Только на страницах типа'),(386,'system','-- choose something --','-- choose something --','-- выберите вариант --'),(387,'component_section','Show only header?','Show only header?','Показывать только заголовок?'),(388,'component_section','Hide on the index page','Hide on the index page','Скрыть на главной?'),(389,'system','Welcome to Floxim.CMS, please sign in','Welcome to Floxim.CMS, please sign in','Welcome to Floxim.CMS, please sign in'),(390,'system','Editing ','Editing ','Редактируем'),(391,'system','Fields table','Fields table','Fields table'),(392,'system','Adding new ','Adding new ','Добавляем'),(393,'controller_component','New infoblock','New infoblock','Новый инфоблок'),(394,'controller_component','Infoblock for the field','Infoblock for the field','Инфоблок для поля '),(396,'system','Name of an entity created by the component','Name of an entity created by the component','Название сущности, создаваемой компонентом'),(397,'system','Component actions','Component actions','Component actions'),(398,'system','Templates','Templates','Шаблоны'),(402,'system','Save','Save','Сохранить'),(403,'system','Used','Used','Used'),(404,'component_section','Nesting level','Nesting level','Уровень вложенности'),(405,'component_section','2 levels','2 levels','2 уровня'),(406,'component_section','3 levels','3 levels','3 уровня'),(407,'component_section','Current level +1','Current level +1','Текущий +1'),(408,'component_section','No limit','No limit','Без ограничения'),(409,'system','Cancel','Cancel','Отменить'),(410,'system','Redo','Redo','Вернуть'),(411,'system','More','More','Еще'),(412,'system','Patches',NULL,'Патчи'),(413,'system','Update check failed',NULL,'Проверка обновлений завершилась неудачей'),(414,'system','Installing patch %s...',NULL,'Устанавливаем патч %s...'),(415,'content','Current Floxim version:',NULL,'Текущая версия Floxim:'),(433,'system','Название компонента (по-русски)','Название компонента (по-русски)','Название компонента'),(439,'system','Add new component','Add new component','Добавить новый компонент'),(440,'system','Add new Components','Add new Components','Добавить новые компоненты'),(441,'system','Add new widget','Add new widget','Создать новый виджет'),(442,'system','Add new field','Add new field','Создать новое поле'),(443,'system','Keyword (название папки с макетом)','Keyword (название папки с макетом)','Ключевое слово'),(444,'system','Layout keyword','Layout keyword','Ключевое слово лейаута'),(445,'system','Add new layout','Add new layout','Создать новый лейаут'),(446,'system','Finish','Finish','Закончить'),(447,'system','Keyword can only contain letters, numbers, symbols, \\\"hyphen\\\" and \\\"underscore\\\"','Keyword can only contain letters, numbers, symbols, \\\"hyphen\\\" and \\\"underscore\\\"',NULL),(452,'controller_component','Limit','Limit','Ограничение'),(453,'controller_component','Conditoins','Conditoins','Условия'),(454,'controller_component','Conditions','Conditions','Условия'),(455,'controller_component','Infoblock page','Infoblock page','Страница инфоблока'),(456,'system','I am REALLY sure','I am REALLY sure','Я действительно уверен'),(457,'component_section','Source infoblock','Source infoblock','Инфоблок-источник'),(459,'system','Email','Email','E-mail'),(460,'system','Edit User','Edit User','Редактировать пользователя'),(462,'system','Admin','Admin','Админ'),(463,'system','Fill in email','Fill in email','Заполните e-mail'),(464,'system','Add new user','Add new user','Создать нового пользователя'),(465,'system','Fill in correct email','Fill in correct email','Укажите корректный e-mail'),(466,'system','Fill in name','Fill in name','Укажите название'),(467,'system','Ununique email','Ununique email','Неуникальный e-mail'),(470,'controller_component','Selected','Selected','Выбраны'),(477,'controller_component','Count entries','Count entries','Число записей'),(484,'system','Block wrapper','Block wrapper','Оформление блока'),(485,'system','Template2','Template2','Шаблон2'),(486,'system','NOW() by default','NOW() by default','СЕЙЧАС по умолчанию'),(487,'system','Languages','Languages','Языки'),(488,'system','Add new language','Add new language','Создать новый язык'),(492,'system','Language name','Language name','Название языка (по-английски)'),(493,'system','Enter english language name','Enter english language name','Укажите название языка на английском'),(494,'system','Native language name','Native language name','Самоназвание языка'),(495,'system','Enter native language name','Enter native language name','Укажите самоназвание языка'),(496,'system','Language code','Language code','Код языка'),(497,'system','Enter language code','Enter language code','Укажите код языка'),(498,'system','Create a new language','Create a new language','Создать новый язык'),(499,'system','Naitive name','Naitive name','Оригинальное название'),(500,'component_section','Add subsection to','Add subsection to','Добавить подраздел в...'),(501,'system','Language','Language','Язык'),(503,'system','Inherited from','Inherited from','Унаследовано от'),(504,'system','Editable','Editable','Редактируемое'),(505,'system','No','No','Нет'),(506,'system','Yes','Yes','Да'),(507,'system','Inherited','Inherited','Унаследовано'),(753,'system','Logs','Logs','Логи'),(754,'system','Request','Request','Запрос'),(755,'system','Date','Date','Дата'),(756,'system','Time','Time','Время'),(757,'system','Entries','Entries','Записи'),(758,'system','Delte','Delte','Удалить'),(759,'system','Delete all','Delete all','Удалить все'),(761,'component_section','Breadcrumbs','Breadcrumbs','Хлебные крошки'),(762,'controller_component','Add items to','Add items to','Добавлять записи в'),(763,'controller_component','Bind items to','Bind items to','Привязывать записи к'),(764,'widget_blockset','Block set','Block set','Набор блоков'),(765,'controller_component','Paginate?','Paginate?','Постраничный вывод?'),(901,'system','Fake infoblock data','Fake infoblock data','Здесь будут данные инфоблока'),(994,'system','Layout settings','Layout settings','Настройки лейаута'),(995,'system','Edit current page','Edit current page','Редактировать текущую страницу'),(996,'system','Use wider rule','Use wider rule','Использовать более широкое правило'),(997,'system','Drop current rule and use the wider one','Drop current rule and use the wider one','Удалить текущее правило и использовать более общее'),(998,'system','For admin only','For admin only','Только для администратора'),(999,'system','Count items','Count items','Количество объектов'),(1000,'system','Count','Count','Сколько'),(1019,'widget_grid','Two columns','Two columns','Две колонки'),(1021,'system','Language strings','Language strings','Языковые строки'),(1025,'system','Key','Key','Ключ'),(1026,'system','Value','Value','Значение'),(1028,'system','Dictionary','Dictionary','Словарь'),(1029,'system','String','String','Строка'),(1050,'component_section','Menu','Menu','Меню'),(1051,'system','settings','settings','Настройки'),(1052,'system','delete','delete','Удалить'),(1053,'system','Import','Import','Импортировать'),(1054,'system','Edit','Edit','Редактировать'),(1055,'system','Edit strings','Edit strings','Редактировать строки'),(1056,'system','Current Floxim version:','Current Floxim version:','Текущая версия Floxim:'),(1057,'system','Name','Name','Название'),(1058,'system','Edit user','Edit user','Редактировать пользователя'),(1059,'system','All pages','All pages','Все страницы'),(1060,'system','All pages of type %s','All pages of type %s','Все страницы, имеющие тип «%s»'),(1061,'system','%s children only','%s children only','Только потомки %s'),(1062,'system','%s and children','%s and children','%s и потомки'),(1063,'system','%s only','%s only','Только %s'),(1064,'system','Scope','Scope','Где показывать'),(1065,'system','%s children of type %s','%s children of type %s','Потомки «%s», имеющие тип «%s»'),(1066,'system','Add','Add','Добавить'),(1067,'controller_component','by filter','by filter','по фильтру'),(1068,'system','Console','Console','Консоль'),(1069,'system','Apply','Apply','Применить'),(1070,'system','Execute','Execute','Выполнить'),(1071,'component_user','New %s password','New %s password','Новый пароль на %s'),(1072,'component_user','Hello, %s! Your new password: %s','Hello, %s! Your new password: %s','Здравствуйте, %s! Ваш новый пароль: %s'),(1073,'system','Add user','Add user','Добавить пользователя'),(1074,'system','Version','Version','Версия'),(1075,'system','Previous','Previous','Предыдущий'),(1076,'system','Status','Status','Статус'),(1077,'system','Install','Install','Установить'),(1078,'system','User name','User name','Имя пользователя'),(1079,'system','Items','Items','Объекты'),(1080,'system','Unable to save essence \"lang_string\"','Unable to save essence \"lang_string\"','Не удается сохранить языковую строку'),(1081,'system','HTML code snippet','HTML code snippet','Фрагмент HTML-кода'),(1082,'system','Is admin?','Is admin?','Администратор?'),(1083,'system','Is multi-language field?','Is multi-language field?','Многоязычное поле?'),(1084,'system','Nane','Nane',NULL),(1085,'system','Field name','Field name','Название поля'),(1086,'controller_component','Auto','Auto','Автоматически'),(1087,'controller_component','Group by parent','Group by parent','Группировать по родителю'),(1088,'system',' by tag',' by tag','по тегу'),(1089,'system','Standard','Standard','Стандартный'),(1090,'system','Local','Local',NULL),(1091,'system','Page infoblocks','Page infoblocks','Инфоблоки страницы'),(1092,'system','Visibility','Visibility','Видимость'),(1093,'system','Area','Area','Область'),(1094,'system','%d items','%d items','%d элементов'),(1095,'component_section','Add subsection','Add subsection','Добавить подраздел'),(1096,'system','Wrapper','Wrapper','Оформление'),(1097,'system','Linking field','Linking field','Ссылающееся поле'),(1098,'system','Linked datatype','Linked datatype','Связанный тип данных'),(1099,'system','Unable to save entity \"LangString\"','Unable to save entity \"LangString\"',NULL),(1100,'system','Vendor','Vendor','Вендор'),(1101,'controller_component','Target infoblock','Target infoblock',NULL),(1102,'controller_component','After submission...','After submission...','После отправки...'),(1103,'system','Refresh page','Refresh page','Обновить страницу'),(1104,'system','Go to the created page','Go to the created page','Перейти к созданной странице'),(1105,'system','Go to the parent page','Go to the parent page','Перейти к родительской странице'),(1106,'system','After login','After login','После входа'),(1107,'system','Refresh current page','Refresh current page','Обновить текущую страницу'),(1108,'system','Redirect to homepage','Redirect to homepage','Перейти на главную'),(1109,'system','Redirect to custom URL...','Redirect to custom URL...','Перейти к указанному URL'),(1110,'system','Target URL','Target URL','URL назначения'),(1111,'system','The content contains some descendants','The content contains some descendants','Объект имеет потомков'),(1112,'system','items. These items will be removed.','items. These items will be removed.','штук. Они будут удалены.'),(1113,'system','after','after','после'),(1114,'system','before','before','перед'),(1115,'system','Delete infoblock','Delete infoblock','Удалить блок'),(1116,'system','Unable to save entity \"langstring\"','Unable to save entity \"langstring\"',NULL),(1117,'system','Please enter valid e-mail adress!','Please enter valid e-mail adress!','Укажите допустимый e-mail'),(1118,'system','Select','Select','Выбрать'),(1119,'system','Change theme','Change theme','Сменить тему'),(1120,'system','Cancel preview','Cancel preview','Отменить предпросмотр'),(1121,'system','Login after registration','Login after registration','Войти после регистрации'),(1122,'system','View','View','Просмотр'),(1123,'system','Welcome to Floxim CMS! Please sign in.','Welcome to Floxim CMS! Please sign in.','Вас приветствует Floxim. Пожалуйста, войдите в систему.'),(1124,'system','Back to log in','Back to log in','Вернуться к форме входа'),(1125,'system','I\'ve lost my password','I\'ve lost my password','Я забыл пароль'),(1126,'system','Remember me','Remember me','Запомнить меня'),(1127,'system','Log in','Log in','Войти'),(1128,'system','Send me new password','Send me new password','Получить новый пароль'),(1129,'controller_component','Allow doubles','Allow doubles','Разрешить дубли'),(1130,'system','Infoblock','Infoblock','Инфоблок'),(1131,'system','parent','parent','родитель'),(1132,'system','Parent','Parent','Родитель'),(1133,'system','Is required','Is required','Обязательное'),(1134,'system','Field \"%s\" is required','Field \"%s\" is required','Поле \"%s\" обязательно для заполнения'),(1135,'system','Unable to save entity \"field\"','Unable to save entity \"field\"',NULL),(1136,'system','Specify field keyword','Specify field keyword','Укажите ключевое слово для поля'),(1137,'system','Declension','Declension','Склонение'),(1138,'system','This field is required','This field is required','Это обязательное поле'),(1139,'system','Unable to save entity \"floxim.nav.section\"','Unable to save entity \"floxim.nav.section\"',NULL),(1140,'system','Unable to save entity \"floxim.blog.news\"','Unable to save entity \"floxim.blog.news\"',NULL),(1141,'system','Unable to save entity \"floxim.nav.external_link\"','Unable to save entity \"floxim.nav.external_link\"',NULL),(1142,'system','Unable to save entity \"floxim.corporate.project\"','Unable to save entity \"floxim.corporate.project\"',NULL),(1143,'system','Confirm','Confirm','Подтвердить'),(1144,'system','Unable to save entity \"floxim.user.user\"','Unable to save entity \"floxim.user.user\"',NULL),(1145,'system','Unable to save entity \"gs.contacts.contact\"','Unable to save entity \"gs.contacts.contact\"',NULL),(1146,'system','Unable to save entity \"gs.contacts.phone\"','Unable to save entity \"gs.contacts.phone\"',NULL),(1147,'system','Is abstract?','Is abstract?','Абстрактный?'),(1148,'system','Unable to save entity \"gs.contacts.link\"','Unable to save entity \"gs.contacts.link\"',NULL),(1149,'system','Unable to save entity \"gs.contacts.address\"','Unable to save entity \"gs.contacts.address\"',NULL),(1150,'system','Login form','Login form','Форма входа'),(1151,'floxim.main.user','After login','After login','После входа...'),(1152,'floxim.main.user','Greet and logout widget','Greet and logout widget','Виджет приветствия и выхода'),(1153,'floxim.main.user','Recover password form','Recover password form','Форма восстановления пароля'),(1154,'floxim.main.user','Registration form','Registration form','Форма регистрации'),(1155,'floxim.main.user','Login form','Login form','Форма входа'),(1156,'controller_component','New block with %s','New block with %s','Новый блок с %s'),(1157,'controller_component','%s by filter','%s by filter','%s'),(1158,'controller_component','%s selected','%s selected','%s'),(1159,'controller_component','Neighbour %s','Neighbour %s','Соседние %s'),(1160,'system','Section','Section','Раздел'),(1161,'system','from this list','from this list','из этого списка'),(1162,'system','Only link will be removed, not %s itself','Only link will be removed, not %s itself','Будет удалена только ссылка, %s останется '),(1163,'system','delete_from_list','delete_from_list','Убрать'),(1164,'system',', it will be available in the %s section',', it will be available in the %s section','в разделе &laquo;%s&raquo;'),(1165,'system','Design settings','Design settings','Оформление'),(1166,'system','Contains','Contains','Содержит'),(1167,'system','Not contains','Not contains','Не содержит'),(1168,'system','datecond_next','datecond_next','Ближайшие'),(1169,'system','datecond_last','datecond_last','Последние'),(1170,'system','in future','in future','В будущем'),(1171,'system','in past','in past','В прошлом'),(1172,'system','DAYS','DAYS','дней'),(1173,'system','WEEKS','WEEKS','недель'),(1174,'system','MONTHS','MONTHS','месяцев'),(1175,'system','YEARS','YEARS','лет'),(1176,'system','Selected entries','Selected entries','Выбранные записи'),(1177,'system','Current page','Current page','Текущая страница'),(1178,'system','Not current page','Not current page','Не текущая страница'),(1179,'system','mode_view','View','Просмотр'),(1180,'system','mode_edit','Edit','Редактирование'),(1181,'controller_component','Pass-through data','Pass-through data','Сквозные данные?'),(1182,'system','%s %s children only','%s %s children only','Только потомки %s «%s»'),(1183,'system','%s %s and children','%s %s and children','%s «%s» и потомки'),(1184,'system','%s %s only','%s %s only','Только %s «%s»'),(1185,'system','%s %s children of type %s','%s %s children of type %s','Потомки %s «%s», имеющие тип «%s»'),(1186,'system','Meta fields','Meta fields','Мета-поля'),(1187,'system','Columns','Columns','Колонки'),(1188,'system','Delete this infoblock','Delete this infoblock','Удалить этот блок'),(1189,'system','You can put blocks here','You can put blocks here','Сюда можно будет добавить блоки'),(1190,'system','%s is empty, you can add blocks here','%s is empty, you can add blocks here','%s еще не содержит блоков, их можно будет добавить сюда позже.'),(1191,'system','Column %s','Column %s','Колонка №%s'),(1192,'system','%s page','%s page',NULL),(1193,'system','Use AJAX','Use AJAX',NULL),(1194,'system','Cascade delete','Cascade delete',NULL),(1195,'system','Is editable','Is editable','Можно редактировать'),(1196,'system','FX_ADMIN_FIELD_GROUP','FX_ADMIN_FIELD_GROUP',NULL),(1197,'system','Continue','Continue',NULL),(1198,'system','Field view','Field view',NULL),(1199,'system','Select list','Select list',NULL),(1200,'system','Radio list','Radio list',NULL),(1201,'system','Livesearch','Livesearch',NULL),(1202,'system','Field group','Field group',NULL),(1203,'system','Is available','Is available','Доступен'),(1204,'system','Use by default','Use by default','Использовать по умолчанию'),(1205,'system','User not found or password is wrong','User not found or password is wrong',NULL),(1206,'system','Theme','Theme',NULL),(1207,'system','Favorite','Favorite',NULL),(1208,'system','Default','Default',NULL);
/*!40000 ALTER TABLE `fx_lang_string` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `fx_layout`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fx_layout` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `keyword` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 AVG_ROW_LENGTH=64;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `fx_layout` WRITE;
/*!40000 ALTER TABLE `fx_layout` DISABLE KEYS */;
INSERT INTO `fx_layout` VALUES (14,'floxim_saas.red','Красненькая'),(15,'floxim_saas.squares','Квадратики');
/*!40000 ALTER TABLE `fx_layout` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `fx_module`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fx_module` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `keyword` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `installed` tinyint(4) NOT NULL DEFAULT '0',
  `inside_admin` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `checked` tinyint(4) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `Checked` (`checked`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AVG_ROW_LENGTH=68;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `fx_module` WRITE;
/*!40000 ALTER TABLE `fx_module` DISABLE KEYS */;
/*!40000 ALTER TABLE `fx_module` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `fx_option`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fx_option` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `keyword` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `value` text NOT NULL,
  `autoload` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `autoload` (`autoload`),
  KEY `keyword` (`keyword`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `fx_option` WRITE;
/*!40000 ALTER TABLE `fx_option` DISABLE KEYS */;
INSERT INTO `fx_option` VALUES (1,'fx.version','Current Floxim version','0.1.1',1);
/*!40000 ALTER TABLE `fx_option` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `fx_patch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fx_patch` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `to` varchar(255) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `description` char(255) NOT NULL,
  `from` varchar(255) NOT NULL,
  `status` varchar(20) NOT NULL,
  `url` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `fx_patch` WRITE;
/*!40000 ALTER TABLE `fx_patch` DISABLE KEYS */;
INSERT INTO `fx_patch` VALUES (20,'0.1.1','2013-08-19 15:24:17','Test patch','0.1.0','installed','http://floxim.org/getfloxim/patches/0.1.0-0.1.1/patch_0.1.1.zip');
/*!40000 ALTER TABLE `fx_patch` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `fx_patch_migration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fx_patch_migration` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `fx_patch_migration` WRITE;
/*!40000 ALTER TABLE `fx_patch_migration` DISABLE KEYS */;
INSERT INTO `fx_patch_migration` VALUES (1,'m20140808_062932','2014-08-13 04:36:44'),(2,'m20140812_050811','2014-08-13 04:36:44'),(3,'m20141208_084116','2014-12-09 07:49:48'),(4,'m20150901_145806','2015-09-25 12:42:14'),(5,'m20150901_161253','2015-09-25 12:42:14');
/*!40000 ALTER TABLE `fx_patch_migration` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `fx_scope`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fx_scope` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `conditions` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `fx_scope` WRITE;
/*!40000 ALTER TABLE `fx_scope` DISABLE KEYS */;
/*!40000 ALTER TABLE `fx_scope` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `fx_select_value`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fx_select_value` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `keyword` varchar(60) NOT NULL,
  `field_id` int(11) NOT NULL,
  `name_en` varchar(255) NOT NULL,
  `name_ru` varchar(255) NOT NULL,
  `description_en` text NOT NULL,
  `description_ru` text NOT NULL,
  `priority` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `fx_select_value` WRITE;
/*!40000 ALTER TABLE `fx_select_value` DISABLE KEYS */;
INSERT INTO `fx_select_value` VALUES (1,'real',459,'Simple page','Обычная','','',1),(2,'external',459,'','Внешняя','','',2),(5,'alias',459,'','Внутренняя','','',3),(6,'none',459,'','Без ссылки','','',4);
/*!40000 ALTER TABLE `fx_select_value` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `fx_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fx_session` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `session_key` char(32) NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `site_id` int(10) unsigned DEFAULT NULL,
  `start_time` int(11) NOT NULL DEFAULT '0',
  `last_activity_time` int(11) NOT NULL DEFAULT '0',
  `ip` bigint(11) NOT NULL DEFAULT '0',
  `remember` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `User_ID` (`user_id`),
  KEY `session_key` (`session_key`)
) ENGINE=InnoDB AUTO_INCREMENT=70 DEFAULT CHARSET=utf8 AVG_ROW_LENGTH=126;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `fx_session` WRITE;
/*!40000 ALTER TABLE `fx_session` DISABLE KEYS */;
INSERT INTO `fx_session` VALUES (69,'cd5eb44c8f48629767b2561831aeb9be',3211,NULL,1456496944,1457532162,2130706433,0);
/*!40000 ALTER TABLE `fx_session` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `fx_site`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fx_site` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `domain` varchar(128) NOT NULL,
  `layout_id` int(11) NOT NULL DEFAULT '0',
  `layout_style_variant` varchar(255) NOT NULL,
  `color` int(11) NOT NULL DEFAULT '0' COMMENT 'Расцветка',
  `mirrors` text NOT NULL,
  `priority` int(11) DEFAULT NULL,
  `checked` smallint(6) NOT NULL DEFAULT '0',
  `index_page_id` int(11) NOT NULL DEFAULT '0',
  `error_page_id` int(11) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_updated` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `robots` text,
  `disallow_indexing` int(11) DEFAULT '0',
  `type` enum('useful','mobile') NOT NULL DEFAULT 'useful' COMMENT 'Тип сайта: обычный или мобильный',
  `language` varchar(255) NOT NULL DEFAULT 'en',
  `offline_text` varchar(255) DEFAULT NULL,
  `store_id` text,
  PRIMARY KEY (`id`),
  KEY `Checked` (`checked`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 AVG_ROW_LENGTH=292;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `fx_site` WRITE;
/*!40000 ALTER TABLE `fx_site` DISABLE KEYS */;
/*!40000 ALTER TABLE `fx_site` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `fx_url_alias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fx_url_alias` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(255) DEFAULT NULL,
  `site_id` int(11) NOT NULL DEFAULT '0',
  `page_id` int(11) NOT NULL DEFAULT '0',
  `is_original` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `url` (`url`),
  KEY `page_id` (`page_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1937 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `fx_url_alias` WRITE;
/*!40000 ALTER TABLE `fx_url_alias` DISABLE KEYS */;
INSERT INTO `fx_url_alias` VALUES (1896,'/',22,5195,1);
/*!40000 ALTER TABLE `fx_url_alias` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `fx_widget`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fx_widget` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name_en` varchar(255) NOT NULL,
  `name_ru` varchar(255) NOT NULL,
  `keyword` varchar(255) NOT NULL,
  `description_en` text,
  `description_ru` text NOT NULL,
  `checked` tinyint(1) NOT NULL DEFAULT '1',
  `vendor` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 AVG_ROW_LENGTH=111;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `fx_widget` WRITE;
/*!40000 ALTER TABLE `fx_widget` DISABLE KEYS */;
INSERT INTO `fx_widget` VALUES (4,'Block set','Набор блоков','floxim.layout.blockset','','',1,''),(8,'Grid','Сетка','floxim.layout.grid',NULL,'',1,''),(9,'Сustom code','','floxim.layout.custom_code',NULL,'',1,''),(10,'Map','','floxim.corporate.map',NULL,'',1,'std'),(11,'','Хлебные крошки','floxim.nav.breadcrumbs',NULL,'',1,'');
/*!40000 ALTER TABLE `fx_widget` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

